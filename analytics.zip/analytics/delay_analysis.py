import csv
import os
from collections import defaultdict


BASE_DIR = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)

ANALYTICS_DIR = os.path.join(
    BASE_DIR,
    "analytics"
)

INPUT_FILE = os.path.join(
    ANALYTICS_DIR,
    "logistics_analytical_dataset.csv"
)

OUTPUT_FILE = os.path.join(
    ANALYTICS_DIR,
    "delay_analysis.csv"
)

VALIDATION_FILE = os.path.join(
    ANALYTICS_DIR,
    "DELAY_ANALYSIS_VALIDATION.txt"
)


def read_csv_file(filepath):

    with open(
        filepath,
        "r",
        encoding="utf-8-sig",
        newline=""
    ) as file:

        return list(csv.DictReader(file))


def main():

    print("=" * 70)
    print("PHASE 7.3 - DELIVERY & DELAY PATTERN ANALYSIS")
    print("=" * 70)

    print("\nLoading frozen Phase 7.1 analytical dataset...")

    records = read_csv_file(INPUT_FILE)

    print(
        f"Analytical records loaded : {len(records):,}"
    )

    if not records:
        print("\nERROR: Analytical dataset is empty.")
        return

    # =========================================================
    # OVERALL DELIVERY METRICS
    # =========================================================

    delays = []
    delivery_times = []

    delayed_count = 0
    on_time_count = 0
    failed_count = 0

    total_order_value = 0.0

    for record in records:

        delay = float(
            record.get("delay_minutes", 0) or 0
        )

        delivery_time = float(
            record.get("delivery_time_minutes", 0) or 0
        )

        order_value = float(
            record.get("order_value", 0) or 0
        )

        status = (
            record.get("delivery_status")
            or "UNKNOWN"
        ).upper()

        delays.append(delay)
        delivery_times.append(delivery_time)

        total_order_value += order_value

        if delay > 0:
            delayed_count += 1
        else:
            on_time_count += 1

        if status == "FAILED":
            failed_count += 1

    total_records = len(records)

    # ---------------------------------------------------------
    # IMPORTANT:
    # Average delay is calculated ONLY across delayed
    # deliveries, matching the Phase 6 KPI definition.
    # ---------------------------------------------------------

    delayed_values = [
        delay
        for delay in delays
        if delay > 0
    ]

    average_delay = (
        sum(delayed_values) / len(delayed_values)
        if delayed_values
        else 0
    )

    maximum_delay = (
        max(delays)
        if delays
        else 0
    )

    minimum_delay = (
        min(delays)
        if delays
        else 0
    )

    average_delivery_time = (
        sum(delivery_times) / total_records
        if total_records
        else 0
    )

    maximum_delivery_time = (
        max(delivery_times)
        if delivery_times
        else 0
    )

    delayed_rate = (
        delayed_count / total_records * 100
        if total_records
        else 0
    )

    on_time_rate = (
        on_time_count / total_records * 100
        if total_records
        else 0
    )

    # =========================================================
    # DELAY SEVERITY BANDS
    # =========================================================

    delay_bands = {
        "ON_TIME": 0,
        "LOW_DELAY_1_15": 0,
        "MEDIUM_DELAY_16_30": 0,
        "HIGH_DELAY_31_60": 0,
        "CRITICAL_DELAY_60_PLUS": 0
    }

    for delay in delays:

        if delay <= 0:
            delay_bands["ON_TIME"] += 1

        elif delay <= 15:
            delay_bands["LOW_DELAY_1_15"] += 1

        elif delay <= 30:
            delay_bands["MEDIUM_DELAY_16_30"] += 1

        elif delay <= 60:
            delay_bands["HIGH_DELAY_31_60"] += 1

        else:
            delay_bands["CRITICAL_DELAY_60_PLUS"] += 1

    # =========================================================
    # PRIORITY ANALYSIS
    # =========================================================

    priority_data = defaultdict(
        lambda: {
            "orders": 0,
            "delay_total": 0.0,
            "delayed": 0,
            "failed": 0,
            "order_value": 0.0
        }
    )

    for record in records:

        priority = (
            record.get("priority")
            or "UNKNOWN"
        ).upper()

        delay = float(
            record.get("delay_minutes", 0) or 0
        )

        order_value = float(
            record.get("order_value", 0) or 0
        )

        status = (
            record.get("delivery_status")
            or "UNKNOWN"
        ).upper()

        priority_data[priority]["orders"] += 1

        priority_data[priority]["delay_total"] += delay

        priority_data[priority]["order_value"] += order_value

        if delay > 0:
            priority_data[priority]["delayed"] += 1

        if status == "FAILED":
            priority_data[priority]["failed"] += 1

    priority_results = []

    for priority, data in priority_data.items():

        orders = data["orders"]

        priority_results.append(
            {
                "priority": priority,
                "orders": orders,
                "order_value": round(
                    data["order_value"],
                    2
                ),
                "average_delay_minutes": round(
                    data["delay_total"] / data["delayed"]
                    if data["delayed"] > 0
                    else 0,
                    2
                ),
                "delayed_orders": data["delayed"],
                "delayed_rate_pct": round(
                    data["delayed"] / orders * 100,
                    2
                ),
                "failed_deliveries": data["failed"]
            }
        )

    priority_results.sort(
        key=lambda x: x["average_delay_minutes"],
        reverse=True
    )

    # =========================================================
    # RISK-WISE DELAY ANALYSIS
    # =========================================================

    risk_data = defaultdict(
        lambda: {
            "orders": 0,
            "delay_total": 0.0,
            "delayed": 0,
            "order_value": 0.0
        }
    )

    for record in records:

        risk = (
            record.get("risk_level")
            or "UNKNOWN"
        ).upper()

        delay = float(
            record.get("delay_minutes", 0) or 0
        )

        order_value = float(
            record.get("order_value", 0) or 0
        )

        risk_data[risk]["orders"] += 1

        risk_data[risk]["delay_total"] += delay

        risk_data[risk]["order_value"] += order_value

        if delay > 0:
            risk_data[risk]["delayed"] += 1

    risk_results = []

    for risk, data in risk_data.items():

        orders = data["orders"]

        risk_results.append(
            {
                "risk_level": risk,
                "orders": orders,
                "average_delay_minutes": round(
                    data["delay_total"] / data["delayed"]
                    if data["delayed"] > 0
                    else 0,
                    2
                ),
                "order_value": round(
                    data["order_value"],
                    2
                )
            }
        )

    risk_order = {
        "CRITICAL": 1,
        "HIGH": 2,
        "MEDIUM": 3,
        "LOW": 4
    }

    risk_results.sort(
        key=lambda x: risk_order.get(
            x["risk_level"],
            99
        )
    )

    # =========================================================
    # WRITE ANALYTICAL OUTPUT
    # =========================================================

    output_rows = []

    for band, count in delay_bands.items():

        output_rows.append(
            {
                "analysis_type": "DELAY_BAND",
                "category": band,
                "orders": count,
                "average_delay_minutes": "",
                "delayed_rate_pct": "",
                "order_value": ""
            }
        )

    for row in priority_results:

        output_rows.append(
            {
                "analysis_type": "PRIORITY",
                "category": row["priority"],
                "orders": row["orders"],
                "average_delay_minutes":
                    row["average_delay_minutes"],
                "delayed_rate_pct":
                    row["delayed_rate_pct"],
                "order_value":
                    row["order_value"]
            }
        )

    fieldnames = [
        "analysis_type",
        "category",
        "orders",
        "average_delay_minutes",
        "delayed_rate_pct",
        "order_value"
    ]

    with open(
        OUTPUT_FILE,
        "w",
        encoding="utf-8",
        newline=""
    ) as file:

        writer = csv.DictWriter(
            file,
            fieldnames=fieldnames
        )

        writer.writeheader()
        writer.writerows(output_rows)

    # =========================================================
    # EXTREME EXCEPTIONS
    # =========================================================

    maximum_delay_record = max(
        records,
        key=lambda x: float(
            x.get("delay_minutes", 0) or 0
        )
    )

    highest_delay_priority = (
        priority_results[0]
        if priority_results
        else None
    )

    highest_risk_delay = max(
        risk_results,
        key=lambda x: x["average_delay_minutes"]
    )

    # =========================================================
    # VALIDATION REPORT
    # =========================================================

    validation_lines = [

        "REAL-TIME LOGISTICS CONTROL TOWER",
        "PHASE 7.3 DELIVERY & DELAY PATTERN VALIDATION",
        "",

        "STATUS: COMPLETE",
        "",

        "SOURCE DATA",
        f"Analytical records: {total_records:,}",
        "",

        "OVERALL DELIVERY PERFORMANCE",

        "Average delay definition: "
        "Average delay across delayed deliveries only",

        f"Average delay among delayed deliveries: "
        f"{average_delay:.2f} minutes",

        f"Maximum delay: "
        f"{maximum_delay:.2f} minutes",

        f"Minimum delay: "
        f"{minimum_delay:.2f} minutes",

        f"Average delivery time: "
        f"{average_delivery_time:.2f} minutes",

        f"Maximum delivery time: "
        f"{maximum_delivery_time:.2f} minutes",

        f"Delayed deliveries: "
        f"{delayed_count:,}",

        f"Delayed rate: "
        f"{delayed_rate:.2f}%",

        f"On-time deliveries: "
        f"{on_time_count:,}",

        f"On-time rate: "
        f"{on_time_rate:.2f}%",

        f"Failed deliveries: "
        f"{failed_count:,}",

        "",

        "DELAY SEVERITY",

        f"On time: "
        f"{delay_bands['ON_TIME']:,}",

        f"1-15 min delay: "
        f"{delay_bands['LOW_DELAY_1_15']:,}",

        f"16-30 min delay: "
        f"{delay_bands['MEDIUM_DELAY_16_30']:,}",

        f"31-60 min delay: "
        f"{delay_bands['HIGH_DELAY_31_60']:,}",

        f"60+ min delay: "
        f"{delay_bands['CRITICAL_DELAY_60_PLUS']:,}",

        "",

        "EXTREME EXCEPTION",

        f"Maximum delay shipment: "
        f"{maximum_delay_record.get('shipment_id', '')}",

        f"Maximum delay: "
        f"{float(maximum_delay_record.get('delay_minutes', 0) or 0):.2f} minutes",

        f"Maximum delay zone: "
        f"{maximum_delay_record.get('destination_zone', '')}",

        f"Maximum delay risk: "
        f"{maximum_delay_record.get('risk_level', '')}",

        "",

        "HIGHEST DELAY PRIORITY",

        (
            f"Priority: "
            f"{highest_delay_priority['priority']}"
            if highest_delay_priority
            else "Priority: N/A"
        ),

        (
            f"Average delay among delayed shipments: "
            f"{highest_delay_priority['average_delay_minutes']:.2f} minutes"
            if highest_delay_priority
            else "Average delay: N/A"
        ),

        "",

        "RISK DELAY PATTERN",

        f"Highest average delay risk level: "
        f"{highest_risk_delay['risk_level']}",

        f"Average delay among delayed shipments: "
        f"{highest_risk_delay['average_delay_minutes']:.2f} minutes",

        "",

        "OUTPUT FILE",
        OUTPUT_FILE,

        "",

        "PHASE 7.3 STATUS: FROZEN"
    ]

    with open(
        VALIDATION_FILE,
        "w",
        encoding="utf-8"
    ) as file:

        file.write(
            "\n".join(validation_lines)
        )

    # =========================================================
    # DISPLAY RESULTS
    # =========================================================

    print("\n" + "=" * 70)
    print("DELIVERY & DELAY PERFORMANCE")
    print("=" * 70)

    print(
        f"Average delay (delayed): "
        f"{average_delay:.2f} minutes"
    )

    print(
        f"Maximum delay          : "
        f"{maximum_delay:.2f} minutes"
    )

    print(
        f"Average delivery time  : "
        f"{average_delivery_time:.2f} minutes"
    )

    print(
        f"Delayed deliveries     : "
        f"{delayed_count:,}"
    )

    print(
        f"Delayed rate           : "
        f"{delayed_rate:.2f}%"
    )

    print(
        f"On-time deliveries     : "
        f"{on_time_count:,}"
    )

    print(
        f"On-time rate           : "
        f"{on_time_rate:.2f}%"
    )

    print(
        f"Failed deliveries      : "
        f"{failed_count:,}"
    )

    print("\nDELAY SEVERITY")
    print("-" * 70)

    print(
        f"On time                : "
        f"{delay_bands['ON_TIME']:,}"
    )

    print(
        f"1-15 min               : "
        f"{delay_bands['LOW_DELAY_1_15']:,}"
    )

    print(
        f"16-30 min              : "
        f"{delay_bands['MEDIUM_DELAY_16_30']:,}"
    )

    print(
        f"31-60 min              : "
        f"{delay_bands['HIGH_DELAY_31_60']:,}"
    )

    print(
        f"60+ min                : "
        f"{delay_bands['CRITICAL_DELAY_60_PLUS']:,}"
    )

    print("\nPRIORITY ANALYSIS")
    print("-" * 70)

    print(
        f"{'PRIORITY':<15}"
        f"{'ORDERS':>10}"
        f"{'AVG DELAY':>15}"
        f"{'DELAYED %':>15}"
    )

    for row in priority_results:

        print(
            f"{row['priority']:<15}"
            f"{row['orders']:>10,}"
            f"{row['average_delay_minutes']:>15.2f}"
            f"{row['delayed_rate_pct']:>15.2f}"
        )

    print("\nRISK-WISE DELAY")
    print("-" * 70)

    for row in risk_results:

        print(
            f"{row['risk_level']:<15}"
            f"Orders: {row['orders']:>5,}   "
            f"Avg Delay: "
            f"{row['average_delay_minutes']:>8.2f} min"
        )

    print("\nEXTREME EXCEPTION")
    print("-" * 70)

    print(
        f"Shipment               : "
        f"{maximum_delay_record.get('shipment_id', '')}"
    )

    print(
        f"Maximum delay          : "
        f"{maximum_delay:.2f} minutes"
    )

    print(
        f"Destination zone       : "
        f"{maximum_delay_record.get('destination_zone', '')}"
    )

    print(
        f"Risk level             : "
        f"{maximum_delay_record.get('risk_level', '')}"
    )

    print("\nOUTPUT")
    print("-" * 70)

    print(
        f"Delay Dataset          : "
        f"{OUTPUT_FILE}"
    )

    print(
        f"Validation Report      : "
        f"{VALIDATION_FILE}"
    )

    # =========================================================
    # FINAL VALIDATION
    # =========================================================

    severity_total = sum(
        delay_bands.values()
    )

    # Phase 6 frozen KPI baseline
    expected_average_delay = 29.93
    expected_delayed_count = 951
    expected_on_time_count = 49
    expected_failed_count = 30

    validation_passed = (
        total_records == 1000
        and severity_total == total_records
        and delayed_count == expected_delayed_count
        and on_time_count == expected_on_time_count
        and failed_count == expected_failed_count
        and abs(
            average_delay - expected_average_delay
        ) < 0.01
    )

    if validation_passed:

        print("\n" + "=" * 70)
        print("RESULT: PHASE 7.3 VALIDATION PASSED")
        print("=" * 70)

    else:

        print("\n" + "=" * 70)
        print("RESULT: VALIDATION ISSUES DETECTED")
        print("=" * 70)


if __name__ == "__main__":
    main()