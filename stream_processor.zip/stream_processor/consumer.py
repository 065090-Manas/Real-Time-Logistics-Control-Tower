import json
from datetime import datetime

from kafka import KafkaConsumer

from config import (
    KAFKA_BOOTSTRAP_SERVERS,
    KAFKA_GROUP_ID,
    KAFKA_TOPICS
)


# ============================================================
# REQUIRED FIELDS
# ============================================================

REQUIRED_FIELDS = {
    "order_events": [
        "event_id",
        "event_timestamp",
        "event_type",
        "order_id",
        "customer_id",
        "origin_zone",
        "destination_zone",
        "warehouse_id",
        "order_value",
        "priority"
    ],

    "shipment_events": [
        "event_id",
        "event_timestamp",
        "event_type",
        "shipment_id",
        "order_id",
        "warehouse_id",
        "zone",
        "vehicle_id"
    ],

    "vehicle_events": [
        "event_id",
        "event_timestamp",
        "event_type",
        "vehicle_id",
        "shipment_id",
        "zone",
        "vehicle_status",
        "speed_kmh"
    ],

    "delivery_events": [
        "event_id",
        "event_timestamp",
        "event_type",
        "shipment_id",
        "order_id",
        "destination_zone",
        "expected_delivery_timestamp",
        "actual_delivery_timestamp",
        "delay_minutes",
        "delivery_status"
    ]
}


# ============================================================
# EVENT VALIDATION
# ============================================================

def validate_event(topic, event):

    if topic not in REQUIRED_FIELDS:
        return False, "Unknown topic"

    missing_fields = [
        field
        for field in REQUIRED_FIELDS[topic]
        if field not in event
    ]

    if missing_fields:
        return False, f"Missing fields: {missing_fields}"

    if not event.get("event_id"):
        return False, "Missing event_id"

    if not event.get("event_timestamp"):
        return False, "Missing event_timestamp"

    return True, "Valid"


# ============================================================
# EVENT ROUTING
# ============================================================

def route_event(topic):

    routes = {
        "order_events": "ORDER",
        "shipment_events": "SHIPMENT",
        "vehicle_events": "VEHICLE",
        "delivery_events": "DELIVERY"
    }

    return routes.get(topic, "UNKNOWN")


# ============================================================
# TIMESTAMP PARSER
# ============================================================

def parse_timestamp(value):

    if value is None:
        raise ValueError("Timestamp is None")

    value = str(value).strip()

    if not value:
        raise ValueError("Timestamp is empty")

    value = value.replace("Z", "")

    if "+" in value:
        value = value.split("+")[0]

    try:
        return datetime.fromisoformat(value)

    except ValueError:
        pass

    formats = [
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d %H:%M",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%dT%H:%M"
    ]

    for fmt in formats:

        try:
            return datetime.strptime(
                value,
                fmt
            )

        except ValueError:
            continue

    raise ValueError(
        f"Unable to parse timestamp: {repr(value)}"
    )


# ============================================================
# VEHICLE ENRICHMENT
# ============================================================

def enrich_vehicle_event(
    event,
    orders,
    shipments
):

    shipment_id = event.get(
        "shipment_id"
    )

    shipment = shipments.get(
        shipment_id
    )

    if not shipment:
        return None

    order_id = shipment.get(
        "order_id"
    )

    order = orders.get(
        order_id
    )

    if not order:
        return None

    return {
        "event_id":
            event.get("event_id"),

        "vehicle_id":
            event.get("vehicle_id"),

        "shipment_id":
            shipment_id,

        "order_id":
            order_id,

        "vehicle_status":
            event.get("vehicle_status"),

        "speed_kmh":
            event.get("speed_kmh"),

        "current_zone":
            event.get("zone"),

        "warehouse_id":
            shipment.get("warehouse_id"),

        "destination_zone":
            order.get("destination_zone"),

        "order_value":
            order.get("order_value"),

        "priority":
            order.get("priority")
    }


# ============================================================
# 6.8 RISK DETECTION ENGINE
# ============================================================

def calculate_risk_level(
    delay_minutes,
    vehicle_status,
    priority,
    delivery_status
):

    delay_minutes = float(
        delay_minutes or 0
    )

    vehicle_status = str(
        vehicle_status or "MOVING"
    ).upper()

    priority = str(
        priority or "STANDARD"
    ).upper()

    delivery_status = str(
        delivery_status or "DELIVERED"
    ).upper()

    # --------------------------------------------------------
    # FAILED DELIVERY = CRITICAL
    # --------------------------------------------------------

    if delivery_status == "FAILED":

        return "CRITICAL"

    # --------------------------------------------------------
    # BASE RISK FROM DELAY
    # --------------------------------------------------------

    if delay_minutes > 60:

        risk_score = 4

    elif delay_minutes > 30:

        risk_score = 3

    elif delay_minutes > 15:

        risk_score = 2

    else:

        risk_score = 1

    # --------------------------------------------------------
    # VEHICLE CONDITION
    # --------------------------------------------------------

    if vehicle_status in [
        "STOPPED",
        "DELAYED"
    ]:

        risk_score += 1

    # --------------------------------------------------------
    # PRIORITY
    # --------------------------------------------------------

    if priority == "HIGH":

        risk_score += 1

    elif (
        priority == "EXPRESS"
        and delay_minutes > 0
    ):

        risk_score += 1

    # --------------------------------------------------------
    # CAP SCORE
    # --------------------------------------------------------

    risk_score = min(
        risk_score,
        4
    )

    # --------------------------------------------------------
    # FINAL RISK LEVEL
    # --------------------------------------------------------

    if risk_score >= 4:

        return "CRITICAL"

    elif risk_score == 3:

        return "HIGH"

    elif risk_score == 2:

        return "MEDIUM"

    else:

        return "LOW"


# ============================================================
# RISK SCORE
# ============================================================

def get_risk_score(risk_level):

    scores = {
        "LOW": 1,
        "MEDIUM": 2,
        "HIGH": 3,
        "CRITICAL": 4
    }

    return scores.get(
        risk_level,
        0
    )


# ============================================================
# BUILD RISK RECORD
# ============================================================

def build_risk_record(
    delivery,
    shipments,
    vehicles,
    orders
):

    shipment_id = delivery.get(
        "shipment_id"
    )

    order_id = delivery.get(
        "order_id"
    )

    shipment = shipments.get(
        shipment_id,
        {}
    )

    order = orders.get(
        order_id,
        {}
    )

    vehicle_id = shipment.get(
        "vehicle_id"
    )

    vehicle = vehicles.get(
        vehicle_id,
        {}
    )

    delay_minutes = float(
        delivery.get(
            "delay_minutes",
            0
        )
    )

    vehicle_status = vehicle.get(
        "vehicle_status",
        "UNKNOWN"
    )

    priority = order.get(
        "priority",
        "Standard"
    )

    delivery_status = delivery.get(
        "delivery_status",
        "UNKNOWN"
    )

    risk_level = calculate_risk_level(
        delay_minutes,
        vehicle_status,
        priority,
        delivery_status
    )

    risk_score = get_risk_score(
        risk_level
    )

    return {

        "shipment_id":
            shipment_id,

        "order_id":
            order_id,

        "vehicle_id":
            vehicle_id,

        "destination_zone":
            order.get(
                "destination_zone"
            ),

        "priority":
            priority,

        "delay_minutes":
            delay_minutes,

        "vehicle_status":
            vehicle_status,

        "delivery_status":
            delivery_status,

        "order_value":
            float(
                order.get(
                    "order_value",
                    0
                )
            ),

        "risk_score":
            risk_score,

        "risk_level":
            risk_level
    }


# ============================================================
# RISK DETECTION
# ============================================================

def detect_risks(
    deliveries,
    shipments,
    vehicles,
    orders
):

    risk_records = []

    for delivery in deliveries.values():

        risk_record = build_risk_record(
            delivery,
            shipments,
            vehicles,
            orders
        )

        risk_records.append(
            risk_record
        )

    return risk_records


# ============================================================
# KPI CALCULATION
# ============================================================

def calculate_kpis(
    orders,
    shipments,
    vehicles,
    deliveries
):

    # ========================================================
    # EXECUTIVE KPIs
    # ========================================================

    total_orders = len(
        orders
    )

    total_order_value = sum(
        float(
            order.get(
                "order_value",
                0
            )
        )
        for order in orders.values()
    )

    total_shipments = len(
        shipments
    )

    shipments_in_transit = sum(
        1
        for shipment in shipments.values()
        if shipment.get(
            "event_type"
        ) == "IN_TRANSIT"
    )

    # ========================================================
    # DELIVERY KPIs
    # ========================================================

    total_deliveries = len(
        deliveries
    )

    successful_deliveries = sum(
        1
        for delivery in deliveries.values()
        if delivery.get(
            "delivery_status"
        ) == "DELIVERED"
    )

    failed_deliveries = sum(
        1
        for delivery in deliveries.values()
        if delivery.get(
            "delivery_status"
        ) == "FAILED"
    )

    on_time_deliveries = sum(
        1
        for delivery in deliveries.values()
        if float(
            delivery.get(
                "delay_minutes",
                0
            )
        ) <= 0
    )

    delayed_deliveries = sum(
        1
        for delivery in deliveries.values()
        if float(
            delivery.get(
                "delay_minutes",
                0
            )
        ) > 0
    )

    total_delay_minutes = sum(
        max(
            float(
                delivery.get(
                    "delay_minutes",
                    0
                )
            ),
            0
        )
        for delivery in deliveries.values()
    )

    average_delay = (
        total_delay_minutes
        /
        delayed_deliveries
        if delayed_deliveries > 0
        else 0
    )

    on_time_percentage = (
        (
            on_time_deliveries
            /
            total_deliveries
        )
        * 100
        if total_deliveries > 0
        else 0
    )

    delayed_shipment_rate = (
        (
            delayed_deliveries
            /
            total_deliveries
        )
        * 100
        if total_deliveries > 0
        else 0
    )

    delivery_success_rate = (
        (
            successful_deliveries
            /
            total_deliveries
        )
        * 100
        if total_deliveries > 0
        else 0
    )

    # ========================================================
    # DELIVERY TIME
    # ========================================================

    delivery_durations = []

    matched_orders = 0

    invalid_duration_records = 0

    for delivery in deliveries.values():

        order_id = delivery.get(
            "order_id"
        )

        if not order_id:

            invalid_duration_records += 1

            continue

        order = orders.get(
            order_id
        )

        if not order:

            continue

        matched_orders += 1

        # IMPORTANT:
        # Kafka order events use event_timestamp
        # as the order creation timestamp.

        order_timestamp = order.get(
            "event_timestamp"
        )

        actual_delivery_timestamp = (
            delivery.get(
                "actual_delivery_timestamp"
            )
        )

        if not actual_delivery_timestamp:

            actual_delivery_timestamp = (
                delivery.get(
                    "event_timestamp"
                )
            )

        if not order_timestamp:

            invalid_duration_records += 1

            continue

        if not actual_delivery_timestamp:

            invalid_duration_records += 1

            continue

        try:

            order_time = parse_timestamp(
                order_timestamp
            )

            delivery_time = parse_timestamp(
                actual_delivery_timestamp
            )

            duration_minutes = (
                delivery_time
                -
                order_time
            ).total_seconds() / 60

            if duration_minutes >= 0:

                delivery_durations.append(
                    duration_minutes
                )

            else:

                invalid_duration_records += 1

        except Exception:

            invalid_duration_records += 1

    if delivery_durations:

        average_delivery_time = (
            sum(
                delivery_durations
            )
            /
            len(
                delivery_durations
            )
        )

    else:

        average_delivery_time = 0

    # ========================================================
    # VEHICLE KPIs
    # ========================================================

    delayed_vehicles = sum(
        1
        for vehicle in vehicles.values()
        if vehicle.get(
            "vehicle_status"
        ) == "DELAYED"
    )

    stopped_vehicles = sum(
        1
        for vehicle in vehicles.values()
        if vehicle.get(
            "vehicle_status"
        ) == "STOPPED"
    )

    idle_vehicles = sum(
        1
        for vehicle in vehicles.values()
        if vehicle.get(
            "vehicle_status"
        ) == "IDLE"
    )

    moving_vehicles = sum(
        1
        for vehicle in vehicles.values()
        if vehicle.get(
            "vehicle_status"
        ) == "MOVING"
    )

    # ========================================================
    # KPI VALIDATION
    # ========================================================

    print(
        "\n"
        + "-"
        * 70
    )

    print(
        "KPI CALCULATION VALIDATION"
    )

    print(
        "-"
        * 70
    )

    print(
        f"Matched orders for delivery time : "
        f"{matched_orders:,}"
    )

    print(
        f"Valid duration records           : "
        f"{len(delivery_durations):,}"
    )

    print(
        f"Invalid duration records         : "
        f"{invalid_duration_records:,}"
    )

    print(
        f"Calculated average delivery time : "
        f"{average_delivery_time:.2f} minutes"
    )

    print(
        "-"
        * 70
    )

    return {

        "total_orders":
            total_orders,

        "total_order_value":
            total_order_value,

        "total_shipments":
            total_shipments,

        "shipments_in_transit":
            shipments_in_transit,

        "total_deliveries":
            total_deliveries,

        "successful_deliveries":
            successful_deliveries,

        "failed_deliveries":
            failed_deliveries,

        "on_time_deliveries":
            on_time_deliveries,

        "delayed_deliveries":
            delayed_deliveries,

        "on_time_percentage":
            on_time_percentage,

        "average_delay_minutes":
            average_delay,

        "delayed_shipment_rate":
            delayed_shipment_rate,

        "delivery_success_rate":
            delivery_success_rate,

        "average_delivery_time_minutes":
            average_delivery_time,

        "delayed_vehicles":
            delayed_vehicles,

        "stopped_vehicles":
            stopped_vehicles,

        "idle_vehicles":
            idle_vehicles,

        "moving_vehicles":
            moving_vehicles,

        "matched_orders_for_delivery_time":
            matched_orders,

        "valid_delivery_duration_records":
            len(
                delivery_durations
            ),

        "invalid_delivery_duration_records":
            invalid_duration_records
    }


# ============================================================
# MAIN STREAM PROCESSOR
# ============================================================

def start_consumer():

    print(
        "Starting Logistics Stream Processor..."
    )

    print(
        f"Broker: "
        f"{KAFKA_BOOTSTRAP_SERVERS[0]}"
    )

    print(
        f"Consumer Group: "
        f"{KAFKA_GROUP_ID}"
    )

    print(
        f"Topics: "
        f"{', '.join(KAFKA_TOPICS)}"
    )

    print(
        "-"
        * 70
    )

    consumer = KafkaConsumer(

        *KAFKA_TOPICS,

        bootstrap_servers=
            KAFKA_BOOTSTRAP_SERVERS,

        group_id=
            KAFKA_GROUP_ID,

        auto_offset_reset=
            "earliest",

        enable_auto_commit=
            False,

        consumer_timeout_ms=
            5000
    )

    # ========================================================
    # STATE
    # ========================================================

    orders = {}

    shipments = {}

    vehicles = {}

    deliveries = {}

    vehicle_event_history = []

    processed_event_ids = set()

    # ========================================================
    # COUNTERS
    # ========================================================

    total_events = 0

    valid_events = 0

    invalid_events = 0

    duplicate_events = 0

    route_counts = {

        "ORDER": 0,

        "SHIPMENT": 0,

        "VEHICLE": 0,

        "DELIVERY": 0,

        "UNKNOWN": 0
    }

    print(
        "Consumer connected."
    )

    print(
        "Reading Kafka history and building analytical state..."
    )

    print(
        "-"
        * 70
    )

    # ========================================================
    # CONSUME KAFKA EVENTS
    # ========================================================

    try:

        for message in consumer:

            total_events += 1

            topic = message.topic

            # ------------------------------------------------
            # JSON PARSING
            # ------------------------------------------------

            try:

                event = json.loads(
                    message.value.decode(
                        "utf-8"
                    )
                )

            except (
                json.JSONDecodeError,
                UnicodeDecodeError
            ):

                invalid_events += 1

                continue

            # ------------------------------------------------
            # VALIDATION
            # ------------------------------------------------

            is_valid, validation_message = (
                validate_event(
                    topic,
                    event
                )
            )

            if not is_valid:

                invalid_events += 1

                continue

            valid_events += 1

            # ------------------------------------------------
            # DEDUPLICATION
            # ------------------------------------------------

            event_id = event.get(
                "event_id"
            )

            if event_id in processed_event_ids:

                duplicate_events += 1

                continue

            processed_event_ids.add(
                event_id
            )

            # ------------------------------------------------
            # ROUTING
            # ------------------------------------------------

            route = route_event(
                topic
            )

            route_counts[
                route
            ] += 1

            # ------------------------------------------------
            # STATE
            # ------------------------------------------------

            if route == "ORDER":

                orders[
                    event["order_id"]
                ] = event

            elif route == "SHIPMENT":

                shipments[
                    event["shipment_id"]
                ] = event

            elif route == "VEHICLE":

                vehicles[
                    event["vehicle_id"]
                ] = event

                vehicle_event_history.append(
                    event
                )

            elif route == "DELIVERY":

                deliveries[
                    event["shipment_id"]
                ] = event

            # ------------------------------------------------
            # PROGRESS
            # ------------------------------------------------

            if total_events % 5000 == 0:

                print(
                    f"Processed "
                    f"{total_events:,} events | "
                    f"Unique="
                    f"{len(processed_event_ids):,} | "
                    f"Duplicates="
                    f"{duplicate_events:,}"
                )

    except KeyboardInterrupt:

        print(
            "\nConsumer stopped by user."
        )

    except Exception as error:

        print(
            f"\nStream processing error: "
            f"{error}"
        )

    # ========================================================
    # CROSS-STREAM VEHICLE ENRICHMENT
    # ========================================================

    enriched_vehicle_events = []

    for vehicle_event in vehicle_event_history:

        enriched = enrich_vehicle_event(

            vehicle_event,

            orders,

            shipments
        )

        if enriched:

            enriched_vehicle_events.append(
                enriched
            )

    # ========================================================
    # KPI ENGINE
    # ========================================================

    kpis = calculate_kpis(

        orders,

        shipments,

        vehicles,

        deliveries
    )

    # ========================================================
    # 6.8 RISK ENGINE
    # ========================================================

    risk_records = detect_risks(

        deliveries,

        shipments,

        vehicles,

        orders
    )

    # ========================================================
    # RISK SUMMARY
    # ========================================================

    risk_counts = {

        "LOW": 0,

        "MEDIUM": 0,

        "HIGH": 0,

        "CRITICAL": 0
    }

    for record in risk_records:

        risk_level = record[
            "risk_level"
        ]

        if risk_level in risk_counts:

            risk_counts[
                risk_level
            ] += 1

    # ========================================================
    # BUSINESS IMPACT
    # ========================================================

    at_risk_records = [
        record
        for record in risk_records
        if record["risk_level"]
        in [
            "HIGH",
            "CRITICAL"
        ]
    ]

    high_priority_risk_records = [
        record
        for record in risk_records
        if record["risk_level"]
        in [
            "HIGH",
            "CRITICAL"
        ]
        and str(
            record["priority"]
        ).upper()
        == "HIGH"
    ]

    orders_at_risk = len(
        at_risk_records
    )

    order_value_at_risk = sum(
        record[
            "order_value"
        ]
        for record in at_risk_records
    )

    critical_order_value = sum(
        record[
            "order_value"
        ]
        for record in risk_records
        if record["risk_level"]
        == "CRITICAL"
    )

    # ========================================================
    # CLOSE KAFKA
    # ========================================================

    consumer.close()

    # ========================================================
    # STREAM PROCESSING VALIDATION
    # ========================================================

    print(
        "\n"
        + "="
        * 70
    )

    print(
        "STREAM PROCESSING VALIDATION"
    )

    print(
        "="
        * 70
    )

    print(
        f"Total events read        : "
        f"{total_events:,}"
    )

    print(
        f"Valid events             : "
        f"{valid_events:,}"
    )

    print(
        f"Invalid events           : "
        f"{invalid_events:,}"
    )

    print(
        f"Duplicate events         : "
        f"{duplicate_events:,}"
    )

    # --------------------------------------------------------
    # ROUTING
    # --------------------------------------------------------

    print(
        "\nUnique Routed Events:"
    )

    print(
        f"ORDER                    : "
        f"{route_counts['ORDER']:,}"
    )

    print(
        f"SHIPMENT                 : "
        f"{route_counts['SHIPMENT']:,}"
    )

    print(
        f"VEHICLE                  : "
        f"{route_counts['VEHICLE']:,}"
    )

    print(
        f"DELIVERY                 : "
        f"{route_counts['DELIVERY']:,}"
    )

    # --------------------------------------------------------
    # CROSS-STREAM STATE
    # --------------------------------------------------------

    print(
        "\nCross-Stream State:"
    )

    print(
        f"Orders stored            : "
        f"{len(orders):,}"
    )

    print(
        f"Shipments stored         : "
        f"{len(shipments):,}"
    )

    print(
        f"Vehicles stored          : "
        f"{len(vehicles):,}"
    )

    print(
        f"Deliveries stored        : "
        f"{len(deliveries):,}"
    )

    print(
        f"Vehicle events enriched  : "
        f"{len(enriched_vehicle_events):,}"
    )

    # ========================================================
    # KPI OUTPUT
    # ========================================================

    print(
        "\n"
        + "="
        * 70
    )

    print(
        "REAL-TIME LOGISTICS KPI ENGINE"
    )

    print(
        "="
        * 70
    )

    print(
        "\nEXECUTIVE KPIs"
    )

    print(
        "-"
        * 70
    )

    print(
        f"Total Orders             : "
        f"{kpis['total_orders']:,}"
    )

    print(
        f"Total Order Value        : "
        f"₹{kpis['total_order_value']:,.2f}"
    )

    print(
        f"Total Shipments          : "
        f"{kpis['total_shipments']:,}"
    )

    print(
        f"Shipments In Transit     : "
        f"{kpis['shipments_in_transit']:,}"
    )

    print(
        f"On-Time Delivery %       : "
        f"{kpis['on_time_percentage']:.2f}%"
    )

    print(
        f"Average Delivery Time    : "
        f"{kpis['average_delivery_time_minutes']:.2f} min"
    )

    # ========================================================
    # OPERATIONAL KPIs
    # ========================================================

    print(
        "\nOPERATIONAL KPIs"
    )

    print(
        "-"
        * 70
    )

    print(
        f"Average Delay            : "
        f"{kpis['average_delay_minutes']:.2f} min"
    )

    print(
        f"Delayed Shipments        : "
        f"{kpis['delayed_deliveries']:,}"
    )

    print(
        f"Delayed Shipment Rate    : "
        f"{kpis['delayed_shipment_rate']:.2f}%"
    )

    print(
        f"Delivery Success Rate    : "
        f"{kpis['delivery_success_rate']:.2f}%"
    )

    print(
        f"Failed Deliveries        : "
        f"{kpis['failed_deliveries']:,}"
    )

    # ========================================================
    # VEHICLE KPIs
    # ========================================================

    print(
        "\nVEHICLE KPIs"
    )

    print(
        "-"
        * 70
    )

    print(
        f"Delayed Vehicles         : "
        f"{kpis['delayed_vehicles']:,}"
    )

    print(
        f"Stopped Vehicles         : "
        f"{kpis['stopped_vehicles']:,}"
    )

    print(
        f"Idle Vehicles            : "
        f"{kpis['idle_vehicles']:,}"
    )

    print(
        f"Moving Vehicles          : "
        f"{kpis['moving_vehicles']:,}"
    )

    # ========================================================
    # KPI DATA QUALITY
    # ========================================================

    print(
        "\nKPI DATA QUALITY"
    )

    print(
        "-"
        * 70
    )

    print(
        f"Matched Order-Delivery  : "
        f"{kpis['matched_orders_for_delivery_time']:,}"
    )

    print(
        f"Valid Duration Records  : "
        f"{kpis['valid_delivery_duration_records']:,}"
    )

    print(
        f"Invalid Duration Records: "
        f"{kpis['invalid_delivery_duration_records']:,}"
    )

    # ========================================================
    # 6.8 RISK DETECTION OUTPUT
    # ========================================================

    print(
        "\n"
        + "="
        * 70
    )

    print(
        "6.8 RISK DETECTION ENGINE"
    )

    print(
        "="
        * 70
    )

    print(
        f"Risk records generated  : "
        f"{len(risk_records):,}"
    )

    print(
        "\nRISK DISTRIBUTION"
    )

    print(
        "-"
        * 70
    )

    print(
        f"LOW                      : "
        f"{risk_counts['LOW']:,}"
    )

    print(
        f"MEDIUM                   : "
        f"{risk_counts['MEDIUM']:,}"
    )

    print(
        f"HIGH                     : "
        f"{risk_counts['HIGH']:,}"
    )

    print(
        f"CRITICAL                 : "
        f"{risk_counts['CRITICAL']:,}"
    )

    # ========================================================
    # RISK PERCENTAGES
    # ========================================================

    total_risk_records = len(
        risk_records
    )

    print(
        "\nRISK PERCENTAGES"
    )

    print(
        "-"
        * 70
    )

    for level in [
        "LOW",
        "MEDIUM",
        "HIGH",
        "CRITICAL"
    ]:

        percentage = (

            (
                risk_counts[level]
                /
                total_risk_records
            )
            * 100

            if total_risk_records > 0
            else 0
        )

        print(
            f"{level:<24}: "
            f"{percentage:.2f}%"
        )

    # ========================================================
    # BUSINESS IMPACT
    # ========================================================

    print(
        "\nBUSINESS IMPACT"
    )

    print(
        "-"
        * 70
    )

    print(
        f"Orders at Risk          : "
        f"{orders_at_risk:,}"
    )

    print(
        f"Order Value at Risk     : "
        f"₹{order_value_at_risk:,.2f}"
    )

    print(
        f"Critical Order Value    : "
        f"₹{critical_order_value:,.2f}"
    )

    print(
        f"High-Priority Risk      : "
        f"{len(high_priority_risk_records):,}"
    )

    # ========================================================
    # HIGH / CRITICAL EXCEPTIONS
    # ========================================================

    priority_records = sorted(
        at_risk_records,
        key=lambda x: (
            -x["risk_score"],
            -x["delay_minutes"],
            -x["order_value"]
        )
    )

    print(
        "\nTOP PRIORITY EXCEPTIONS"
    )

    print(
        "-"
        * 70
    )

    if priority_records:

        for record in priority_records[:10]:

            print(
                f"{record['risk_level']:<10} | "
                f"{record['shipment_id']:<10} | "
                f"{record['order_id']:<10} | "
                f"Delay: "
                f"{record['delay_minutes']:.0f} min | "
                f"Vehicle: "
                f"{record['vehicle_status']:<8} | "
                f"Priority: "
                f"{record['priority']:<8} | "
                f"Zone: "
                f"{record['destination_zone']}"
            )

    else:

        print(
            "No HIGH or CRITICAL exceptions detected."
        )

    # ========================================================
    # RISK ENGINE VALIDATION
    # ========================================================

    print(
        "\n"
        + "="
        * 70
    )

    print(
        "RISK ENGINE VALIDATION"
    )

    print(
        "="
        * 70
    )

    print(
        f"Total risk records      : "
        f"{len(risk_records):,}"
    )

    print(
        f"LOW                    : "
        f"{risk_counts['LOW']:,}"
    )

    print(
        f"MEDIUM                 : "
        f"{risk_counts['MEDIUM']:,}"
    )

    print(
        f"HIGH                   : "
        f"{risk_counts['HIGH']:,}"
    )

    print(
        f"CRITICAL               : "
        f"{risk_counts['CRITICAL']:,}"
    )

    print(
        f"HIGH + CRITICAL        : "
        f"{len(at_risk_records):,}"
    )

    print(
        "Risk detection completed."
    )

    print(
        "="
        * 70
    )

    print(
        "\nKafka consumer closed."
    )

    print(
        "Stream processing completed."
    )


# ============================================================
# PROGRAM ENTRY POINT
# ============================================================

if __name__ == "__main__":

    start_consumer()