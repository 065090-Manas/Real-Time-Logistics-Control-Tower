import csv
import os
from collections import defaultdict


# ============================================================
# PROJECT PATHS
# ============================================================

BASE_DIR = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)

ANALYTICS_DIR = os.path.join(
    BASE_DIR,
    "analytics"
)

INPUT_FILE = os.path.join(
    ANALYTICS_DIR,
    "logistics_analytical_dataset.csv"
)

RISK_OUTPUT_FILE = os.path.join(
    ANALYTICS_DIR,
    "risk_summary.csv"
)

MATRIX_OUTPUT_FILE = os.path.join(
    ANALYTICS_DIR,
    "priority_risk_matrix.csv"
)

INTERVENTION_OUTPUT_FILE = os.path.join(
    ANALYTICS_DIR,
    "intervention_candidates.csv"
)

VALIDATION_FILE = os.path.join(
    ANALYTICS_DIR,
    "RISK_PRIORITY_VALIDATION.txt"
)


# ============================================================
# READ CSV
# ============================================================

def read_csv_file(filepath):

    with open(
        filepath,
        "r",
        encoding="utf-8-sig",
        newline=""
    ) as file:

        return list(csv.DictReader(file))


# ============================================================
# SAFE NUMERIC CONVERSION
# ============================================================

def to_float(value):

    try:
        return float(value or 0)
    except (ValueError, TypeError):
        return 0.0


# ============================================================
# PRIORITY WEIGHT
# ============================================================

def get_priority_weight(priority):

    priority = str(
        priority or "STANDARD"
    ).upper()

    if priority == "HIGH":
        return 3

    if priority == "EXPRESS":
        return 2

    return 1


# ============================================================
# MAIN ANALYSIS
# ============================================================

def main():

    print("=" * 70)
    print("PHASE 7.4 - RISK & PRIORITY ANALYSIS")
    print("=" * 70)

    print(
        "\nLoading frozen Phase 7.1 analytical dataset..."
    )

    records = read_csv_file(INPUT_FILE)

    print(
        f"Analytical records loaded : {len(records):,}"
    )

    if not records:

        print(
            "\nERROR: Analytical dataset is empty."
        )

        return

    # ========================================================
    # BASIC BUSINESS TOTALS
    # ========================================================

    total_records = len(records)

    total_order_value = sum(
        to_float(
            record.get("order_value")
        )
        for record in records
    )

    # ========================================================
    # RISK SUMMARY
    # ========================================================

    risk_data = defaultdict(
        lambda: {
            "orders": 0,
            "order_value": 0.0,
            "delay_total": 0.0,
            "delayed_orders": 0,
            "failed_deliveries": 0
        }
    )

    for record in records:

        risk = (
            record.get("risk_level")
            or "UNKNOWN"
        ).upper()

        order_value = to_float(
            record.get("order_value")
        )

        delay = to_float(
            record.get("delay_minutes")
        )

        status = (
            record.get("delivery_status")
            or "UNKNOWN"
        ).upper()

        risk_data[risk]["orders"] += 1

        risk_data[risk]["order_value"] += order_value

        risk_data[risk]["delay_total"] += delay

        if delay > 0:
            risk_data[risk]["delayed_orders"] += 1

        if status == "FAILED":
            risk_data[risk]["failed_deliveries"] += 1

    risk_order = [
        "LOW",
        "MEDIUM",
        "HIGH",
        "CRITICAL"
    ]

    risk_results = []

    for risk in risk_order:

        data = risk_data[risk]

        orders = data["orders"]

        average_delay = (
            data["delay_total"] / orders
            if orders > 0
            else 0
        )

        value_share = (
            data["order_value"]
            / total_order_value
            * 100
            if total_order_value > 0
            else 0
        )

        risk_results.append(
            {
                "risk_level": risk,
                "risk_score": {
                    "LOW": 1,
                    "MEDIUM": 2,
                    "HIGH": 3,
                    "CRITICAL": 4
                }[risk],
                "orders": orders,
                "order_value": round(
                    data["order_value"],
                    2
                ),
                "value_share_pct": round(
                    value_share,
                    2
                ),
                "average_delay_minutes": round(
                    average_delay,
                    2
                ),
                "delayed_orders": data["delayed_orders"],
                "failed_deliveries": data["failed_deliveries"]
            }
        )

    # ========================================================
    # PRIORITY × RISK MATRIX
    # ========================================================

    matrix_data = defaultdict(
        lambda: {
            "orders": 0,
            "order_value": 0.0,
            "average_delay_total": 0.0
        }
    )

    for record in records:

        priority = (
            record.get("priority")
            or "STANDARD"
        ).upper()

        risk = (
            record.get("risk_level")
            or "UNKNOWN"
        ).upper()

        key = (
            priority,
            risk
        )

        matrix_data[key]["orders"] += 1

        matrix_data[key]["order_value"] += (
            to_float(
                record.get("order_value")
            )
        )

        matrix_data[key]["average_delay_total"] += (
            to_float(
                record.get("delay_minutes")
            )
        )

    priority_order = [
        "HIGH",
        "EXPRESS",
        "STANDARD"
    ]

    matrix_results = []

    for priority in priority_order:

        for risk in reversed(risk_order):

            data = matrix_data[
                (priority, risk)
            ]

            orders = data["orders"]

            average_delay = (
                data["average_delay_total"]
                / orders
                if orders > 0
                else 0
            )

            matrix_results.append(
                {
                    "priority": priority,
                    "risk_level": risk,
                    "orders": orders,
                    "order_value": round(
                        data["order_value"],
                        2
                    ),
                    "average_delay_minutes": round(
                        average_delay,
                        2
                    )
                }
            )

    # ========================================================
    # BUSINESS EXPOSURE
    # ========================================================

    at_risk_records = [
        record
        for record in records
        if record.get("risk_level")
        in ["HIGH", "CRITICAL"]
    ]

    critical_records = [
        record
        for record in records
        if record.get("risk_level")
        == "CRITICAL"
    ]

    high_priority_risk_records = [
        record
        for record in records
        if (
            record.get("priority", "").upper()
            == "HIGH"
            and record.get("risk_level")
            in ["HIGH", "CRITICAL"]
        )
    ]

    orders_at_risk = len(
        at_risk_records
    )

    order_value_at_risk = sum(
        to_float(
            record.get("order_value")
        )
        for record in at_risk_records
    )

    critical_orders = len(
        critical_records
    )

    critical_order_value = sum(
        to_float(
            record.get("order_value")
        )
        for record in critical_records
    )

    high_priority_at_risk = len(
        high_priority_risk_records
    )

    high_priority_at_risk_value = sum(
        to_float(
            record.get("order_value")
        )
        for record in high_priority_risk_records
    )

    # ========================================================
    # INTERVENTION CANDIDATES
    #
    # Score logic:
    #
    # Risk score       = 100 points per risk level
    # Priority weight  = 10 points per priority level
    # Delay component  = up to 120 points
    # Value component  = up to 20 points
    #
    # This makes risk the dominant decision factor while
    # allowing priority, delay and financial exposure to
    # refine the intervention ranking.
    # ========================================================

    maximum_order_value = max(
        (
            to_float(
                record.get("order_value")
            )
            for record in records
        ),
        default=1
    )

    intervention_candidates = []

    risk_scores = {
        "LOW": 1,
        "MEDIUM": 2,
        "HIGH": 3,
        "CRITICAL": 4
    }

    for record in records:

        risk = (
            record.get("risk_level")
            or "LOW"
        ).upper()

        priority = (
            record.get("priority")
            or "STANDARD"
        ).upper()

        risk_score = risk_scores.get(
            risk,
            1
        )

        priority_weight = get_priority_weight(
            priority
        )

        delay = to_float(
            record.get("delay_minutes")
        )

        order_value = to_float(
            record.get("order_value")
        )

        risk_component = (
            risk_score * 100
        )

        priority_component = (
            priority_weight * 10
        )

        delay_component = min(
            delay,
            120
        )

        value_component = (
            order_value
            / maximum_order_value
            * 20
        )

        intervention_score = (
            risk_component
            + priority_component
            + delay_component
            + value_component
        )

        candidate = {
            "shipment_id":
                record.get("shipment_id", ""),

            "order_id":
                record.get("order_id", ""),

            "vehicle_id":
                record.get("vehicle_id", ""),

            "destination_zone":
                record.get("destination_zone", ""),

            "priority":
                priority,

            "risk_level":
                risk,

            "risk_score":
                risk_score,

            "delay_minutes":
                round(delay, 2),

            "order_value":
                round(order_value, 2),

            "vehicle_status":
                record.get(
                    "vehicle_status",
                    ""
                ),

            "delivery_status":
                record.get(
                    "delivery_status",
                    ""
                ),

            "intervention_score":
                round(
                    intervention_score,
                    2
                )
        }

        intervention_candidates.append(
            candidate
        )

    # Highest intervention score first
    intervention_candidates.sort(
        key=lambda x: (
            x["intervention_score"],
            x["order_value"],
            x["delay_minutes"]
        ),
        reverse=True
    )

    # Keep top 20 for management intervention view
    top_intervention_candidates = (
        intervention_candidates[:20]
    )

    # ========================================================
    # WRITE RISK SUMMARY
    # ========================================================

    risk_fieldnames = [
        "risk_level",
        "risk_score",
        "orders",
        "order_value",
        "value_share_pct",
        "average_delay_minutes",
        "delayed_orders",
        "failed_deliveries"
    ]

    with open(
        RISK_OUTPUT_FILE,
        "w",
        encoding="utf-8",
        newline=""
    ) as file:

        writer = csv.DictWriter(
            file,
            fieldnames=risk_fieldnames
        )

        writer.writeheader()
        writer.writerows(
            risk_results
        )

    # ========================================================
    # WRITE PRIORITY × RISK MATRIX
    # ========================================================

    matrix_fieldnames = [
        "priority",
        "risk_level",
        "orders",
        "order_value",
        "average_delay_minutes"
    ]

    with open(
        MATRIX_OUTPUT_FILE,
        "w",
        encoding="utf-8",
        newline=""
    ) as file:

        writer = csv.DictWriter(
            file,
            fieldnames=matrix_fieldnames
        )

        writer.writeheader()
        writer.writerows(
            matrix_results
        )

    # ========================================================
    # WRITE INTERVENTION CANDIDATES
    # ========================================================

    intervention_fieldnames = [
        "shipment_id",
        "order_id",
        "vehicle_id",
        "destination_zone",
        "priority",
        "risk_level",
        "risk_score",
        "delay_minutes",
        "order_value",
        "vehicle_status",
        "delivery_status",
        "intervention_score"
    ]

    with open(
        INTERVENTION_OUTPUT_FILE,
        "w",
        encoding="utf-8",
        newline=""
    ) as file:

        writer = csv.DictWriter(
            file,
            fieldnames=intervention_fieldnames
        )

        writer.writeheader()
        writer.writerows(
            top_intervention_candidates
        )

    # ========================================================
    # TOP RISK SHIPMENT
    # ========================================================

    top_risk_shipment = max(
        records,
        key=lambda record: (
            risk_scores.get(
                record.get(
                    "risk_level",
                    "LOW"
                ).upper(),
                1
            ),
            to_float(
                record.get(
                    "delay_minutes"
                )
            ),
            to_float(
                record.get(
                    "order_value"
                )
            )
        )
    )

    # ========================================================
    # TOP FINANCIAL EXPOSURE
    # ========================================================

    top_value_risk = max(
        at_risk_records,
        key=lambda record: to_float(
            record.get(
                "order_value"
            )
        ),
        default=None
    )

    # ========================================================
    # VALIDATION
    # ========================================================

    risk_total = sum(
        row["orders"]
        for row in risk_results
    )

    risk_value_total = sum(
        row["order_value"]
        for row in risk_results
    )

    matrix_total = sum(
        row["orders"]
        for row in matrix_results
    )

    matrix_value_total = sum(
        row["order_value"]
        for row in matrix_results
    )

    validation_passed = (
        total_records == 1000
        and risk_total == total_records
        and matrix_total == total_records
        and orders_at_risk == 344
        and critical_orders == 225
        and high_priority_at_risk == 42
        and abs(
            risk_value_total
            - total_order_value
        ) < 0.01
        and abs(
            matrix_value_total
            - total_order_value
        ) < 0.01
        and abs(
            order_value_at_risk
            - 12776135.22
        ) < 0.01
        and abs(
            critical_order_value
            - 8475152.65
        ) < 0.01
    )

    # ========================================================
    # VALIDATION REPORT
    # ========================================================

    validation_lines = [

        "REAL-TIME LOGISTICS CONTROL TOWER",
        "PHASE 7.4 RISK & PRIORITY ANALYSIS VALIDATION",
        "",

        "STATUS: COMPLETE",
        "",

        "SOURCE DATA",
        f"Analytical records: {total_records:,}",
        f"Total order value: ₹{total_order_value:,.2f}",
        "",

        "RISK DISTRIBUTION",
        f"LOW: {risk_data['LOW']['orders']:,}",
        f"MEDIUM: {risk_data['MEDIUM']['orders']:,}",
        f"HIGH: {risk_data['HIGH']['orders']:,}",
        f"CRITICAL: {risk_data['CRITICAL']['orders']:,}",
        "",

        "BUSINESS EXPOSURE",
        f"Orders at Risk: {orders_at_risk:,}",
        f"Order Value at Risk: ₹{order_value_at_risk:,.2f}",
        f"Critical Orders: {critical_orders:,}",
        f"Critical Order Value: ₹{critical_order_value:,.2f}",
        f"High-Priority Orders at Risk: {high_priority_at_risk:,}",
        f"High-Priority Order Value at Risk: "
        f"₹{high_priority_at_risk_value:,.2f}",
        "",

        "RECONCILIATION",
        f"Risk records: {risk_total:,}",
        f"Matrix records: {matrix_total:,}",
        f"Risk order value: ₹{risk_value_total:,.2f}",
        f"Matrix order value: ₹{matrix_value_total:,.2f}",
        "",

        "TOP RISK SHIPMENT",
        f"Shipment: "
        f"{top_risk_shipment.get('shipment_id', '')}",
        f"Risk: "
        f"{top_risk_shipment.get('risk_level', '')}",
        f"Priority: "
        f"{top_risk_shipment.get('priority', '')}",
        f"Delay: "
        f"{to_float(top_risk_shipment.get('delay_minutes')):.2f} minutes",
        f"Order value: "
        f"₹{to_float(top_risk_shipment.get('order_value')):,.2f}",
        f"Destination zone: "
        f"{top_risk_shipment.get('destination_zone', '')}",
        "",

        "TOP FINANCIAL EXPOSURE",
        (
            f"Shipment: "
            f"{top_value_risk.get('shipment_id', '')}"
            if top_value_risk
            else "Shipment: N/A"
        ),
        (
            f"Order value: "
            f"₹{to_float(top_value_risk.get('order_value')):,.2f}"
            if top_value_risk
            else "Order value: N/A"
        ),
        (
            f"Risk: "
            f"{top_value_risk.get('risk_level', '')}"
            if top_value_risk
            else "Risk: N/A"
        ),
        "",

        "INTERVENTION MODEL",
        "Risk is the dominant intervention factor.",
        "Priority, delay and order value refine the ranking.",
        "Top 20 intervention candidates exported.",
        "",

        "OUTPUT FILES",
        RISK_OUTPUT_FILE,
        MATRIX_OUTPUT_FILE,
        INTERVENTION_OUTPUT_FILE,
        VALIDATION_FILE,
        ""
    ]

    if validation_passed:

        validation_lines.append(
            "PHASE 7.4 STATUS: FROZEN"
        )

    else:

        validation_lines.append(
            "PHASE 7.4 STATUS: VALIDATION ISSUES DETECTED"
        )

    with open(
        VALIDATION_FILE,
        "w",
        encoding="utf-8"
    ) as file:

        file.write(
            "\n".join(validation_lines)
        )

    # ========================================================
    # DISPLAY RESULTS
    # ========================================================

    print("\n" + "=" * 70)
    print("RISK DISTRIBUTION")
    print("=" * 70)

    print(
        f"{'RISK':<15}"
        f"{'ORDERS':>10}"
        f"{'VALUE':>18}"
        f"{'VALUE %':>12}"
        f"{'AVG DELAY':>14}"
    )

    print("-" * 70)

    for row in risk_results:

        print(
            f"{row['risk_level']:<15}"
            f"{row['orders']:>10,}"
            f"₹{row['order_value']:>16,.2f}"
            f"{row['value_share_pct']:>11.2f}%"
            f"{row['average_delay_minutes']:>14.2f}"
        )

    print("\n" + "=" * 70)
    print("PRIORITY × RISK MATRIX")
    print("=" * 70)

    print(
        f"{'PRIORITY':<15}"
        f"{'RISK':<15}"
        f"{'ORDERS':>10}"
        f"{'ORDER VALUE':>18}"
    )

    print("-" * 70)

    for row in matrix_results:

        if row["orders"] > 0:

            print(
                f"{row['priority']:<15}"
                f"{row['risk_level']:<15}"
                f"{row['orders']:>10,}"
                f"₹{row['order_value']:>16,.2f}"
            )

    print("\n" + "=" * 70)
    print("BUSINESS EXPOSURE")
    print("=" * 70)

    print(
        f"Orders at Risk              : "
        f"{orders_at_risk:,}"
    )

    print(
        f"Order Value at Risk         : "
        f"₹{order_value_at_risk:,.2f}"
    )

    print(
        f"Critical Orders             : "
        f"{critical_orders:,}"
    )

    print(
        f"Critical Order Value        : "
        f"₹{critical_order_value:,.2f}"
    )

    print(
        f"High-Priority Orders at Risk: "
        f"{high_priority_at_risk:,}"
    )

    print(
        f"High-Priority Value at Risk : "
        f"₹{high_priority_at_risk_value:,.2f}"
    )

    print("\n" + "=" * 70)
    print("TOP 10 INTERVENTION CANDIDATES")
    print("=" * 70)

    print(
        f"{'RANK':<6}"
        f"{'SHIPMENT':<14}"
        f"{'ZONE':<14}"
        f"{'PRIORITY':<11}"
        f"{'RISK':<11}"
        f"{'DELAY':>10}"
        f"{'VALUE':>16}"
    )

    print("-" * 70)

    for index, candidate in enumerate(
        top_intervention_candidates[:10],
        start=1
    ):

        print(
            f"{index:<6}"
            f"{candidate['shipment_id']:<14}"
            f"{candidate['destination_zone']:<14}"
            f"{candidate['priority']:<11}"
            f"{candidate['risk_level']:<11}"
            f"{candidate['delay_minutes']:>8.2f}m"
            f"₹{candidate['order_value']:>14,.2f}"
        )

    print("\n" + "=" * 70)
    print("VALIDATION")
    print("=" * 70)

    print(
        f"Total records             : "
        f"{total_records:,}"
    )

    print(
        f"Risk records              : "
        f"{risk_total:,}"
    )

    print(
        f"Matrix records            : "
        f"{matrix_total:,}"
    )

    print(
        f"Orders at Risk            : "
        f"{orders_at_risk:,}"
    )

    print(
        f"Critical Orders           : "
        f"{critical_orders:,}"
    )

    print(
        f"High-Priority at Risk     : "
        f"{high_priority_at_risk:,}"
    )

    print(
        f"Order Value at Risk       : "
        f"₹{order_value_at_risk:,.2f}"
    )

    print(
        f"Critical Order Value      : "
        f"₹{critical_order_value:,.2f}"
    )

    print("\nOUTPUT")
    print("-" * 70)

    print(
        f"Risk Summary              : "
        f"{RISK_OUTPUT_FILE}"
    )

    print(
        f"Priority-Risk Matrix      : "
        f"{MATRIX_OUTPUT_FILE}"
    )

    print(
        f"Intervention Candidates   : "
        f"{INTERVENTION_OUTPUT_FILE}"
    )

    print(
        f"Validation Report         : "
        f"{VALIDATION_FILE}"
    )

    # ========================================================
    # FINAL RESULT
    # ========================================================

    if validation_passed:

        print("\n" + "=" * 70)
        print(
            "RESULT: PHASE 7.4 VALIDATION PASSED"
        )
        print("=" * 70)

    else:

        print("\n" + "=" * 70)
        print(
            "RESULT: VALIDATION ISSUES DETECTED"
        )
        print("=" * 70)


if __name__ == "__main__":
    main()