import csv
import os
import mysql.connector


# ============================================================
# PROJECT PATHS
# ============================================================

BASE_DIR = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)

ANALYTICS_DIR = os.path.join(
    BASE_DIR,
    "analytics"
)

INPUT_FILE = os.path.join(
    ANALYTICS_DIR,
    "logistics_analytical_dataset.csv"
)


# ============================================================
# MYSQL CONFIGURATION
# ============================================================

MYSQL_HOST = "127.0.0.1"
MYSQL_PORT = 3307
MYSQL_USER = "root"

DATABASE = "logistics_control_tower"
TABLE = "logistics_analytics"


# ============================================================
# HELPERS
# ============================================================

def read_csv_file(filepath):

    with open(
        filepath,
        "r",
        encoding="utf-8-sig",
        newline=""
    ) as file:

        return list(csv.DictReader(file))


def clean_value(value):

    if value is None:
        return None

    value = str(value).strip()

    if value == "":
        return None

    return value


# ============================================================
# MAIN
# ============================================================

def main():

    print("=" * 70)
    print("PHASE 8.2 - ANALYTICAL DATA LOADING")
    print("=" * 70)

    # --------------------------------------------------------
    # LOAD SOURCE DATA
    # --------------------------------------------------------

    print("\nLoading frozen Phase 7.1 analytical dataset...")

    records = read_csv_file(
        INPUT_FILE
    )

    print(
        f"Source records loaded : {len(records):,}"
    )

    if len(records) != 1000:

        print(
            "\nERROR: Expected exactly 1,000 analytical records."
        )

        return

    # --------------------------------------------------------
    # MYSQL PASSWORD
    # --------------------------------------------------------

    password = input(
        "\nEnter MySQL root password: "
    )

    # --------------------------------------------------------
    # CONNECT
    # --------------------------------------------------------

    print("\nConnecting to MySQL...")

    connection = mysql.connector.connect(
        host=MYSQL_HOST,
        port=MYSQL_PORT,
        user=MYSQL_USER,
        password=password,
        database=DATABASE
    )

    cursor = connection.cursor()

    print(
        "MySQL connection successful."
    )

    # --------------------------------------------------------
    # CLEAR EXISTING DATA
    # --------------------------------------------------------

    print(
        "\nClearing existing analytical table..."
    )

    cursor.execute(
        f"TRUNCATE TABLE {TABLE}"
    )

    connection.commit()

    # --------------------------------------------------------
    # INSERT QUERY
    # --------------------------------------------------------

    insert_query = f"""
    INSERT INTO {TABLE} (
        shipment_id,
        order_id,
        vehicle_id,
        warehouse_id,
        origin_zone,
        destination_zone,
        current_vehicle_zone,
        priority,
        order_value,
        delivery_status,
        delay_minutes,
        delivery_time_minutes,
        vehicle_status,
        speed_kmh,
        risk_level,
        risk_score,
        is_at_risk,
        is_critical,
        order_timestamp,
        expected_delivery_timestamp,
        actual_delivery_timestamp,
        duration_valid
    )
    VALUES (
        %s, %s, %s, %s,
        %s, %s, %s, %s,
        %s, %s, %s, %s,
        %s, %s, %s, %s,
        %s, %s, %s, %s,
        %s, %s
    )
    """

    # --------------------------------------------------------
    # PREPARE DATA
    # --------------------------------------------------------

    data = []

    for record in records:

        data.append(
            (
                clean_value(
                    record.get("shipment_id")
                ),

                clean_value(
                    record.get("order_id")
                ),

                clean_value(
                    record.get("vehicle_id")
                ),

                clean_value(
                    record.get("warehouse_id")
                ),

                clean_value(
                    record.get("origin_zone")
                ),

                clean_value(
                    record.get("destination_zone")
                ),

                clean_value(
                    record.get("current_vehicle_zone")
                ),

                clean_value(
                    record.get("priority")
                ),

                clean_value(
                    record.get("order_value")
                ),

                clean_value(
                    record.get("delivery_status")
                ),

                clean_value(
                    record.get("delay_minutes")
                ),

                clean_value(
                    record.get("delivery_time_minutes")
                ),

                clean_value(
                    record.get("vehicle_status")
                ),

                clean_value(
                    record.get("speed_kmh")
                ),

                clean_value(
                    record.get("risk_level")
                ),

                clean_value(
                    record.get("risk_score")
                ),

                clean_value(
                    record.get("is_at_risk")
                ),

                clean_value(
                    record.get("is_critical")
                ),

                clean_value(
                    record.get("order_timestamp")
                ),

                clean_value(
                    record.get(
                        "expected_delivery_timestamp"
                    )
                ),

                clean_value(
                    record.get(
                        "actual_delivery_timestamp"
                    )
                ),

                clean_value(
                    record.get("duration_valid")
                )
            )
        )

    # --------------------------------------------------------
    # INSERT
    # --------------------------------------------------------

    print(
        "\nLoading records into MySQL..."
    )

    cursor.executemany(
        insert_query,
        data
    )

    connection.commit()

    inserted_rows = cursor.rowcount

    print(
        f"Rows inserted          : {inserted_rows:,}"
    )

    # --------------------------------------------------------
    # VALIDATE ROW COUNT
    # --------------------------------------------------------

    cursor.execute(
        f"SELECT COUNT(*) FROM {TABLE}"
    )

    database_count = cursor.fetchone()[0]

    print(
        f"Rows in MySQL          : {database_count:,}"
    )

    # --------------------------------------------------------
    # VALIDATE ORDER VALUE
    # --------------------------------------------------------

    cursor.execute(
        f"""
        SELECT
            ROUND(SUM(order_value), 2)
        FROM {TABLE}
        """
    )

    database_order_value = (
        cursor.fetchone()[0]
        or 0
    )

    print(
        f"Order value in MySQL   : "
        f"₹{database_order_value:,.2f}"
    )

    # --------------------------------------------------------
    # VALIDATE RISK DISTRIBUTION
    # --------------------------------------------------------

    cursor.execute(
        f"""
        SELECT
            risk_level,
            COUNT(*)
        FROM {TABLE}
        GROUP BY risk_level
        ORDER BY
            CASE risk_level
                WHEN 'LOW' THEN 1
                WHEN 'MEDIUM' THEN 2
                WHEN 'HIGH' THEN 3
                WHEN 'CRITICAL' THEN 4
                ELSE 5
            END
        """
    )

    risk_results = cursor.fetchall()

    print("\nRISK DISTRIBUTION IN MYSQL")
    print("-" * 70)

    risk_counts = {}

    for risk, count in risk_results:

        risk_counts[risk] = count

        print(
            f"{risk:<15}: {count:,}"
        )

    # --------------------------------------------------------
    # VALIDATE BUSINESS IMPACT
    # --------------------------------------------------------

    cursor.execute(
        f"""
        SELECT
            COUNT(*)
        FROM {TABLE}
        WHERE risk_level IN ('HIGH', 'CRITICAL')
        """
    )

    mysql_at_risk = cursor.fetchone()[0]

    cursor.execute(
        f"""
        SELECT
            ROUND(SUM(order_value), 2)
        FROM {TABLE}
        WHERE risk_level IN ('HIGH', 'CRITICAL')
        """
    )

    mysql_value_at_risk = (
        cursor.fetchone()[0]
        or 0
    )

    cursor.execute(
        f"""
        SELECT
            COUNT(*)
        FROM {TABLE}
        WHERE risk_level = 'CRITICAL'
        """
    )

    mysql_critical = cursor.fetchone()[0]

    cursor.execute(
        f"""
        SELECT
            ROUND(SUM(order_value), 2)
        FROM {TABLE}
        WHERE risk_level = 'CRITICAL'
        """
    )

    mysql_critical_value = (
        cursor.fetchone()[0]
        or 0
    )

    # --------------------------------------------------------
    # CLOSE CONNECTION
    # --------------------------------------------------------

    cursor.close()
    connection.close()

    # --------------------------------------------------------
    # VALIDATION
    # --------------------------------------------------------

    validation_passed = (
        inserted_rows == 1000
        and database_count == 1000
        and abs(
            float(database_order_value)
            - 37735702.89
        ) < 0.01
        and risk_counts.get("LOW", 0) == 337
        and risk_counts.get("MEDIUM", 0) == 319
        and risk_counts.get("HIGH", 0) == 119
        and risk_counts.get("CRITICAL", 0) == 225
        and mysql_at_risk == 344
        and abs(
            float(mysql_value_at_risk)
            - 12776135.22
        ) < 0.01
        and mysql_critical == 225
        and abs(
            float(mysql_critical_value)
            - 8475152.65
        ) < 0.01
    )

    # --------------------------------------------------------
    # FINAL OUTPUT
    # --------------------------------------------------------

    print("\n" + "=" * 70)
    print("PHASE 8.2 VALIDATION")
    print("=" * 70)

    print(
        f"Source records          : {len(records):,}"
    )

    print(
        f"Rows inserted           : {inserted_rows:,}"
    )

    print(
        f"Rows in MySQL           : {database_count:,}"
    )

    print(
        f"Total order value       : "
        f"₹{database_order_value:,.2f}"
    )

    print(
        f"Orders at Risk          : "
        f"{mysql_at_risk:,}"
    )

    print(
        f"Order Value at Risk     : "
        f"₹{mysql_value_at_risk:,.2f}"
    )

    print(
        f"Critical Orders         : "
        f"{mysql_critical:,}"
    )

    print(
        f"Critical Order Value    : "
        f"₹{mysql_critical_value:,.2f}"
    )

    if validation_passed:

        print("\n" + "=" * 70)
        print(
            "RESULT: PHASE 8.2 VALIDATION PASSED"
        )
        print("=" * 70)

    else:

        print("\n" + "=" * 70)
        print(
            "RESULT: VALIDATION ISSUES DETECTED"
        )
        print("=" * 70)


if __name__ == "__main__":
    main()