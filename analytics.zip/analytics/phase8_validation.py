import mysql.connector
import os


# ============================================================
# MYSQL CONFIGURATION
# ============================================================

MYSQL_HOST = "127.0.0.1"
MYSQL_PORT = 3307
MYSQL_USER = "root"

DATABASE = "logistics_control_tower"

OUTPUT_FILE = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "PHASE8_VALIDATION.txt"
)


# ============================================================
# EXPECTED FROZEN PHASE 7 BASELINE
# ============================================================

EXPECTED = {
    "total_records": 1000,
    "total_order_value": 37735702.89,

    "low_risk": 337,
    "medium_risk": 319,
    "high_risk": 119,
    "critical_risk": 225,

    "orders_at_risk": 344,
    "order_value_at_risk": 12776135.22,

    "critical_orders": 225,
    "critical_order_value": 8475152.65,

    "delayed_orders": 951,
    "on_time_orders": 49,
    "failed_deliveries": 30,

    "average_delay": 29.93,

    "zones": 8,
    "intervention_candidates": 30
}


# ============================================================
# HELPERS
# ============================================================

def money(value):
    return round(float(value or 0), 2)


def close_enough(actual, expected, tolerance=0.01):
    return abs(
        float(actual or 0) - float(expected)
    ) < tolerance


# ============================================================
# MAIN
# ============================================================

def main():

    print("=" * 70)
    print("PHASE 8.4 - MYSQL INTEGRATION VALIDATION & FREEZE")
    print("=" * 70)

    password = input(
        "\nEnter MySQL root password: "
    )

    print("\nConnecting to MySQL...")

    connection = mysql.connector.connect(
        host=MYSQL_HOST,
        port=MYSQL_PORT,
        user=MYSQL_USER,
        password=password,
        database=DATABASE
    )

    cursor = connection.cursor()

    print("MySQL connection successful.")

    tests = []

    def add_test(name, condition):
        tests.append(
            {
                "name": name,
                "passed": bool(condition)
            }
        )

    # ========================================================
    # 1. DATABASE / TABLE CHECK
    # ========================================================

    cursor.execute(
        """
        SELECT COUNT(*)
        FROM information_schema.tables
        WHERE table_schema = %s
        AND table_name = 'logistics_analytics'
        """,
        (DATABASE,)
    )

    table_exists = cursor.fetchone()[0] == 1

    add_test(
        "logistics_analytics table exists",
        table_exists
    )

    # ========================================================
    # 2. MYSQL ROW COUNT
    # ========================================================

    cursor.execute(
        """
        SELECT COUNT(*)
        FROM logistics_analytics
        """
    )

    total_records = cursor.fetchone()[0]

    add_test(
        "MySQL records = 1,000",
        total_records == EXPECTED["total_records"]
    )

    # ========================================================
    # 3. TOTAL ORDER VALUE
    # ========================================================

    cursor.execute(
        """
        SELECT SUM(order_value)
        FROM logistics_analytics
        """
    )

    total_order_value = money(
        cursor.fetchone()[0]
    )

    add_test(
        "MySQL order value reconciles",
        close_enough(
            total_order_value,
            EXPECTED["total_order_value"]
        )
    )

    # ========================================================
    # 4. RISK DISTRIBUTION
    # ========================================================

    cursor.execute(
        """
        SELECT
            risk_level,
            COUNT(*)
        FROM logistics_analytics
        GROUP BY risk_level
        """
    )

    risk_distribution = {
        row[0]: row[1]
        for row in cursor.fetchall()
    }

    add_test(
        "LOW risk = 337",
        risk_distribution.get("LOW", 0) == 337
    )

    add_test(
        "MEDIUM risk = 319",
        risk_distribution.get("MEDIUM", 0) == 319
    )

    add_test(
        "HIGH risk = 119",
        risk_distribution.get("HIGH", 0) == 119
    )

    add_test(
        "CRITICAL risk = 225",
        risk_distribution.get("CRITICAL", 0) == 225
    )

    # ========================================================
    # 5. ORDERS AT RISK
    # ========================================================

    cursor.execute(
        """
        SELECT COUNT(*)
        FROM logistics_analytics
        WHERE risk_level IN ('HIGH', 'CRITICAL')
        """
    )

    orders_at_risk = cursor.fetchone()[0]

    add_test(
        "Orders at Risk = 344",
        orders_at_risk == EXPECTED["orders_at_risk"]
    )

    # ========================================================
    # 6. ORDER VALUE AT RISK
    # ========================================================

    cursor.execute(
        """
        SELECT SUM(order_value)
        FROM logistics_analytics
        WHERE risk_level IN ('HIGH', 'CRITICAL')
        """
    )

    order_value_at_risk = money(
        cursor.fetchone()[0]
    )

    add_test(
        "Order Value at Risk reconciles",
        close_enough(
            order_value_at_risk,
            EXPECTED["order_value_at_risk"]
        )
    )

    # ========================================================
    # 7. CRITICAL ORDERS
    # ========================================================

    cursor.execute(
        """
        SELECT COUNT(*)
        FROM logistics_analytics
        WHERE risk_level = 'CRITICAL'
        """
    )

    critical_orders = cursor.fetchone()[0]

    add_test(
        "Critical Orders = 225",
        critical_orders == EXPECTED["critical_orders"]
    )

    # ========================================================
    # 8. CRITICAL ORDER VALUE
    # ========================================================

    cursor.execute(
        """
        SELECT SUM(order_value)
        FROM logistics_analytics
        WHERE risk_level = 'CRITICAL'
        """
    )

    critical_order_value = money(
        cursor.fetchone()[0]
    )

    add_test(
        "Critical Order Value reconciles",
        close_enough(
            critical_order_value,
            EXPECTED["critical_order_value"]
        )
    )

    # ========================================================
    # 9. DELIVERY PERFORMANCE
    # ========================================================

    cursor.execute(
        """
        SELECT COUNT(*)
        FROM logistics_analytics
        WHERE delay_minutes > 0
        """
    )

    delayed_orders = cursor.fetchone()[0]

    add_test(
        "Delayed deliveries = 951",
        delayed_orders == EXPECTED["delayed_orders"]
    )

    cursor.execute(
        """
        SELECT COUNT(*)
        FROM logistics_analytics
        WHERE delay_minutes <= 0
        """
    )

    on_time_orders = cursor.fetchone()[0]

    add_test(
        "On-time deliveries = 49",
        on_time_orders == EXPECTED["on_time_orders"]
    )

    cursor.execute(
        """
        SELECT COUNT(*)
        FROM logistics_analytics
        WHERE delivery_status = 'FAILED'
        """
    )

    failed_deliveries = cursor.fetchone()[0]

    add_test(
        "Failed deliveries = 30",
        failed_deliveries == EXPECTED["failed_deliveries"]
    )

    # ========================================================
    # 10. AVERAGE DELAY
    # ========================================================

    cursor.execute(
        """
        SELECT AVG(delay_minutes)
        FROM logistics_analytics
        WHERE delay_minutes > 0
        """
    )

    average_delay = round(
        float(cursor.fetchone()[0] or 0),
        2
    )

    add_test(
        "Average delayed-order delay = 29.93 minutes",
        close_enough(
            average_delay,
            EXPECTED["average_delay"]
        )
    )

    # ========================================================
    # 11. ZONE VIEW
    # ========================================================

    cursor.execute(
        """
        SELECT COUNT(*)
        FROM vw_zone_performance
        """
    )

    zone_count = cursor.fetchone()[0]

    add_test(
        "Zone view contains 8 zones",
        zone_count == EXPECTED["zones"]
    )

    # ========================================================
    # 12. RISK VIEW
    # ========================================================

    cursor.execute(
        """
        SELECT SUM(orders)
        FROM vw_risk_distribution
        """
    )

    risk_view_records = cursor.fetchone()[0]

    add_test(
        "Risk view reconciles to 1,000 records",
        risk_view_records == 1000
    )

    # ========================================================
    # 13. PRIORITY-RISK VIEW
    # ========================================================

    cursor.execute(
        """
        SELECT SUM(orders)
        FROM vw_priority_risk
        """
    )

    priority_records = cursor.fetchone()[0]

    add_test(
        "Priority-risk view reconciles to 1,000 records",
        priority_records == 1000
    )

    # ========================================================
    # 14. DELAY VIEW
    # ========================================================

    cursor.execute(
        """
        SELECT SUM(orders)
        FROM vw_delay_performance
        """
    )

    delay_view_records = cursor.fetchone()[0]

    add_test(
        "Delay view reconciles to 1,000 records",
        delay_view_records == 1000
    )

    # ========================================================
    # 15. INTERVENTION VIEW
    # ========================================================

    cursor.execute(
        """
        SELECT COUNT(*)
        FROM vw_intervention_candidates
        """
    )

    intervention_candidates = cursor.fetchone()[0]

    add_test(
        "Intervention candidates = 30",
        intervention_candidates
        == EXPECTED["intervention_candidates"]
    )

    # ========================================================
    # 16. EXECUTIVE KPI VIEW
    # ========================================================

    cursor.execute(
        """
        SELECT
            total_orders,
            total_order_value,
            average_delay_minutes,
            on_time_rate_pct,
            orders_at_risk,
            order_value_at_risk,
            critical_orders,
            critical_order_value,
            failed_deliveries
        FROM vw_executive_kpis
        """
    )

    kpi = cursor.fetchone()

    (
        kpi_total_orders,
        kpi_total_value,
        kpi_average_delay,
        kpi_on_time_rate,
        kpi_orders_at_risk,
        kpi_value_at_risk,
        kpi_critical_orders,
        kpi_critical_value,
        kpi_failed
    ) = kpi

    add_test(
        "Executive KPI total orders = 1,000",
        kpi_total_orders == 1000
    )

    add_test(
        "Executive KPI total value reconciles",
        close_enough(
            kpi_total_value,
            EXPECTED["total_order_value"]
        )
    )

    add_test(
        "Executive KPI average delay reconciles",
        close_enough(
            kpi_average_delay,
            EXPECTED["average_delay"]
        )
    )

    add_test(
        "Executive KPI on-time rate = 4.90%",
        close_enough(
            kpi_on_time_rate,
            4.90
        )
    )

    add_test(
        "Executive KPI orders at risk = 344",
        kpi_orders_at_risk == 344
    )

    add_test(
        "Executive KPI value at risk reconciles",
        close_enough(
            kpi_value_at_risk,
            EXPECTED["order_value_at_risk"]
        )
    )

    add_test(
        "Executive KPI critical orders = 225",
        kpi_critical_orders == 225
    )

    add_test(
        "Executive KPI critical value reconciles",
        close_enough(
            kpi_critical_value,
            EXPECTED["critical_order_value"]
        )
    )

    add_test(
        "Executive KPI failed deliveries = 30",
        kpi_failed == 30
    )

    # ========================================================
    # CLOSE CONNECTION
    # ========================================================

    cursor.close()
    connection.close()

    # ========================================================
    # FINAL TEST COUNT
    # ========================================================

    passed_tests = sum(
        1
        for test in tests
        if test["passed"]
    )

    total_tests = len(tests)

    all_passed = (
        passed_tests == total_tests
    )

    # ========================================================
    # TERMINAL OUTPUT
    # ========================================================

    print("\n" + "=" * 70)
    print("PHASE 8.4 FINAL RECONCILIATION")
    print("=" * 70)

    print(
        f"MySQL records            : "
        f"{total_records:,}"
    )

    print(
        f"Total order value        : "
        f"₹{total_order_value:,.2f}"
    )

    print(
        f"Orders at Risk            : "
        f"{orders_at_risk:,}"
    )

    print(
        f"Order Value at Risk       : "
        f"₹{order_value_at_risk:,.2f}"
    )

    print(
        f"Critical Orders           : "
        f"{critical_orders:,}"
    )

    print(
        f"Critical Order Value      : "
        f"₹{critical_order_value:,.2f}"
    )

    print(
        f"Delayed deliveries        : "
        f"{delayed_orders:,}"
    )

    print(
        f"On-time deliveries        : "
        f"{on_time_orders:,}"
    )

    print(
        f"Failed deliveries         : "
        f"{failed_deliveries:,}"
    )

    print(
        f"Average delay             : "
        f"{average_delay:.2f} minutes"
    )

    print(
        f"Zones                     : "
        f"{zone_count}"
    )

    print(
        f"Intervention candidates   : "
        f"{intervention_candidates}"
    )

    print("\nVALIDATION TESTS")
    print("-" * 70)

    for test in tests:

        status = (
            "PASS"
            if test["passed"]
            else "FAIL"
        )

        print(
            f"[{status}] {test['name']}"
        )

    print("\nTEST SUMMARY")
    print("-" * 70)

    print(
        f"Tests passed             : "
        f"{passed_tests}/{total_tests}"
    )

    # ========================================================
    # WRITE FINAL REPORT
    # ========================================================

    validation_lines = [

        "============================================================",
        "REAL-TIME LOGISTICS CONTROL TOWER",
        "PHASE 8 - DATA STORAGE / INTEGRATION",
        "FINAL VALIDATION & FREEZE",
        "============================================================",
        "",

        "PHASE 8 STATUS",
        (
            "FROZEN - ALL VALIDATION TESTS PASSED"
            if all_passed
            else "VALIDATION ISSUES DETECTED"
        ),
        "",

        "MYSQL DATASET",
        f"Records: {total_records:,}",
        f"Total order value: ₹{total_order_value:,.2f}",
        "",

        "RISK RECONCILIATION",
        f"LOW: {risk_distribution.get('LOW', 0):,}",
        f"MEDIUM: {risk_distribution.get('MEDIUM', 0):,}",
        f"HIGH: {risk_distribution.get('HIGH', 0):,}",
        f"CRITICAL: {risk_distribution.get('CRITICAL', 0):,}",
        f"Orders at Risk: {orders_at_risk:,}",
        f"Order Value at Risk: ₹{order_value_at_risk:,.2f}",
        f"Critical Orders: {critical_orders:,}",
        f"Critical Order Value: ₹{critical_order_value:,.2f}",
        "",

        "DELIVERY RECONCILIATION",
        f"Delayed deliveries: {delayed_orders:,}",
        f"On-time deliveries: {on_time_orders:,}",
        f"Failed deliveries: {failed_deliveries:,}",
        f"Average delay: {average_delay:.2f} minutes",
        "",

        "SQL BUSINESS LAYER",
        f"Zone records: {zone_count}",
        f"Risk view records: {risk_view_records:,}",
        f"Priority-risk records: {priority_records:,}",
        f"Delay view records: {delay_view_records:,}",
        f"Intervention candidates: {intervention_candidates}",
        "",

        "VALIDATION TESTS",
        f"Tests passed: {passed_tests}/{total_tests}",
        ""
    ]

    for test in tests:

        status = (
            "PASS"
            if test["passed"]
            else "FAIL"
        )

        validation_lines.append(
            f"[{status}] {test['name']}"
        )

    validation_lines.extend(
        [
            "",
            "============================================================",
            (
                "PHASE 8 FINAL STATUS: FROZEN"
                if all_passed
                else "PHASE 8 FINAL STATUS: NOT FROZEN"
            ),
            "============================================================",
            "",
            "INTEGRATION CHAIN:",
            "PHASE 7 ANALYTICS",
            "        ↓",
            "MYSQL ANALYTICAL TABLE",
            "        ↓",
            "SQL BUSINESS VIEWS",
            "        ↓",
            "GRAFANA CONTROL TOWER",
            "",
            "NEXT PHASE:",
            "PHASE 9 - CONTROL TOWER DASHBOARD",
            ""
        ]
    )

    with open(
        OUTPUT_FILE,
        "w",
        encoding="utf-8"
    ) as file:

        file.write(
            "\n".join(validation_lines)
        )

    print("\nOUTPUT")
    print("-" * 70)

    print(
        f"Validation report       : "
        f"{OUTPUT_FILE}"
    )

    # ========================================================
    # FINAL RESULT
    # ========================================================

    print("\n" + "=" * 70)

    if all_passed:

        print(
            "RESULT: PHASE 8 VALIDATION PASSED"
        )

        print(
            "PHASE 8 STATUS: FROZEN"
        )

    else:

        print(
            "RESULT: PHASE 8 VALIDATION FAILED"
        )

        print(
            "PHASE 8 STATUS: NOT FROZEN"
        )

    print("=" * 70)


if __name__ == "__main__":
    main()