import csv
import os
from collections import defaultdict


# ============================================================
# PROJECT PATHS
# ============================================================

BASE_DIR = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)

ANALYTICS_DIR = os.path.join(
    BASE_DIR,
    "analytics"
)

INPUT_FILE = os.path.join(
    ANALYTICS_DIR,
    "logistics_analytical_dataset.csv"
)

ZONE_FILE = os.path.join(
    ANALYTICS_DIR,
    "zone_performance.csv"
)

INTERVENTION_FILE = os.path.join(
    ANALYTICS_DIR,
    "intervention_candidates.csv"
)

OUTPUT_FILE = os.path.join(
    ANALYTICS_DIR,
    "business_impact_summary.csv"
)

EXCEPTION_FILE = os.path.join(
    ANALYTICS_DIR,
    "business_exceptions.csv"
)

VALIDATION_FILE = os.path.join(
    ANALYTICS_DIR,
    "BUSINESS_IMPACT_VALIDATION.txt"
)


# ============================================================
# HELPERS
# ============================================================

def read_csv_file(filepath):

    with open(
        filepath,
        "r",
        encoding="utf-8-sig",
        newline=""
    ) as file:

        return list(csv.DictReader(file))


def to_float(value):

    try:
        return float(value or 0)
    except (ValueError, TypeError):
        return 0.0


# ============================================================
# MAIN
# ============================================================

def main():

    print("=" * 70)
    print("PHASE 7.5 - BUSINESS IMPACT & EXCEPTION ANALYSIS")
    print("=" * 70)

    print("\nLoading frozen analytical dataset...")

    records = read_csv_file(INPUT_FILE)

    print(
        f"Analytical records loaded : {len(records):,}"
    )

    if not records:

        print("\nERROR: Analytical dataset is empty.")
        return

    # ========================================================
    # BUSINESS EXPOSURE
    # ========================================================

    total_orders = len(records)

    total_order_value = sum(
        to_float(
            record.get("order_value")
        )
        for record in records
    )

    at_risk_records = [
        record
        for record in records
        if record.get("risk_level", "").upper()
        in ["HIGH", "CRITICAL"]
    ]

    critical_records = [
        record
        for record in records
        if record.get("risk_level", "").upper()
        == "CRITICAL"
    ]

    failed_records = [
        record
        for record in records
        if record.get("delivery_status", "").upper()
        == "FAILED"
    ]

    high_priority_records = [
        record
        for record in records
        if record.get("priority", "").upper()
        == "HIGH"
    ]

    high_priority_risk_records = [
        record
        for record in high_priority_records
        if record.get("risk_level", "").upper()
        in ["HIGH", "CRITICAL"]
    ]

    severe_delay_records = [
        record
        for record in records
        if to_float(
            record.get("delay_minutes")
        ) > 60
    ]

    stopped_vehicle_records = [
        record
        for record in records
        if record.get("vehicle_status", "").upper()
        == "STOPPED"
    ]

    delayed_vehicle_records = [
        record
        for record in records
        if record.get("vehicle_status", "").upper()
        == "DELAYED"
    ]

    orders_at_risk = len(at_risk_records)

    order_value_at_risk = sum(
        to_float(
            record.get("order_value")
        )
        for record in at_risk_records
    )

    critical_orders = len(critical_records)

    critical_order_value = sum(
        to_float(
            record.get("order_value")
        )
        for record in critical_records
    )

    failed_orders = len(failed_records)

    failed_order_value = sum(
        to_float(
            record.get("order_value")
        )
        for record in failed_records
    )

    high_priority_orders = len(
        high_priority_records
    )

    high_priority_at_risk = len(
        high_priority_risk_records
    )

    high_priority_at_risk_value = sum(
        to_float(
            record.get("order_value")
        )
        for record in high_priority_risk_records
    )

    severe_delay_count = len(
        severe_delay_records
    )

    severe_delay_value = sum(
        to_float(
            record.get("order_value")
        )
        for record in severe_delay_records
    )

    stopped_vehicle_count = len(
        stopped_vehicle_records
    )

    delayed_vehicle_count = len(
        delayed_vehicle_records
    )

    # ========================================================
    # BUSINESS IMPACT PERCENTAGES
    # ========================================================

    at_risk_rate = (
        orders_at_risk / total_orders * 100
        if total_orders
        else 0
    )

    at_risk_value_pct = (
        order_value_at_risk
        / total_order_value
        * 100
        if total_order_value
        else 0
    )

    critical_value_pct = (
        critical_order_value
        / total_order_value
        * 100
        if total_order_value
        else 0
    )

    failed_value_pct = (
        failed_order_value
        / total_order_value
        * 100
        if total_order_value
        else 0
    )

    severe_delay_value_pct = (
        severe_delay_value
        / total_order_value
        * 100
        if total_order_value
        else 0
    )

    # ========================================================
    # ZONE BUSINESS IMPACT
    # ========================================================

    zone_data = defaultdict(
        lambda: {
            "orders": 0,
            "order_value": 0.0,
            "at_risk": 0,
            "at_risk_value": 0.0,
            "critical": 0,
            "critical_value": 0.0,
            "failed": 0,
            "failed_value": 0.0,
            "severe_delay": 0
        }
    )

    for record in records:

        zone = (
            record.get("destination_zone")
            or "UNKNOWN"
        ).strip()

        value = to_float(
            record.get("order_value")
        )

        risk = (
            record.get("risk_level")
            or "UNKNOWN"
        ).upper()

        status = (
            record.get("delivery_status")
            or "UNKNOWN"
        ).upper()

        delay = to_float(
            record.get("delay_minutes")
        )

        zone_data[zone]["orders"] += 1

        zone_data[zone]["order_value"] += value

        if risk in ["HIGH", "CRITICAL"]:

            zone_data[zone]["at_risk"] += 1

            zone_data[zone]["at_risk_value"] += value

        if risk == "CRITICAL":

            zone_data[zone]["critical"] += 1

            zone_data[zone]["critical_value"] += value

        if status == "FAILED":

            zone_data[zone]["failed"] += 1

            zone_data[zone]["failed_value"] += value

        if delay > 60:

            zone_data[zone]["severe_delay"] += 1

    zone_results = []

    for zone, data in zone_data.items():

        orders = data["orders"]

        zone_results.append(
            {
                "zone": zone,
                "orders": orders,
                "order_value": round(
                    data["order_value"],
                    2
                ),
                "at_risk_orders": data["at_risk"],
                "at_risk_value": round(
                    data["at_risk_value"],
                    2
                ),
                "critical_orders": data["critical"],
                "critical_value": round(
                    data["critical_value"],
                    2
                ),
                "failed_deliveries": data["failed"],
                "failed_value": round(
                    data["failed_value"],
                    2
                ),
                "severe_delay_orders":
                    data["severe_delay"],
                "risk_rate_pct": round(
                    data["at_risk"]
                    / orders
                    * 100,
                    2
                )
            }
        )

    zone_results.sort(
        key=lambda x: (
            x["at_risk_value"],
            x["critical_orders"]
        ),
        reverse=True
    )

    # ========================================================
    # EXCEPTION CLASSIFICATION
    # ========================================================

    exceptions = []

    for record in records:

        risk = (
            record.get("risk_level")
            or "LOW"
        ).upper()

        priority = (
            record.get("priority")
            or "STANDARD"
        ).upper()

        delay = to_float(
            record.get("delay_minutes")
        )

        value = to_float(
            record.get("order_value")
        )

        vehicle_status = (
            record.get("vehicle_status")
            or "UNKNOWN"
        ).upper()

        delivery_status = (
            record.get("delivery_status")
            or "UNKNOWN"
        ).upper()

        zone = (
            record.get("destination_zone")
            or "UNKNOWN"
        )

        exception_type = "MONITOR"

        action = "Continue monitoring"

        severity = 1

        if delivery_status == "FAILED":

            exception_type = "FAILED_DELIVERY"

            action = (
                "Immediate delivery recovery "
                "and customer-service escalation"
            )

            severity = 5

        elif risk == "CRITICAL" and delay > 60:

            exception_type = "CRITICAL_DELAY"

            action = (
                "Immediate operations intervention"
            )

            severity = 5

        elif risk == "CRITICAL":

            exception_type = "CRITICAL_RISK"

            action = (
                "Immediate shipment review"
            )

            severity = 4

        elif risk == "HIGH" and priority == "HIGH":

            exception_type = "HIGH_PRIORITY_RISK"

            action = (
                "Prioritize for operational intervention"
            )

            severity = 4

        elif risk == "HIGH":

            exception_type = "HIGH_RISK"

            action = (
                "Operations review required"
            )

            severity = 3

        elif vehicle_status in [
            "STOPPED",
            "DELAYED"
        ]:

            exception_type = "VEHICLE_EXCEPTION"

            action = (
                "Fleet review and vehicle intervention"
            )

            severity = 3

        elif delay > 30:

            exception_type = "SIGNIFICANT_DELAY"

            action = (
                "Monitor shipment and investigate delay"
            )

            severity = 2

        exceptions.append(
            {
                "shipment_id":
                    record.get("shipment_id", ""),

                "order_id":
                    record.get("order_id", ""),

                "destination_zone":
                    zone,

                "priority":
                    priority,

                "risk_level":
                    risk,

                "delay_minutes":
                    round(delay, 2),

                "order_value":
                    round(value, 2),

                "vehicle_status":
                    vehicle_status,

                "delivery_status":
                    delivery_status,

                "exception_type":
                    exception_type,

                "severity":
                    severity,

                "recommended_action":
                    action
            }
        )

    # Highest severity, then value, then delay
    exceptions.sort(
        key=lambda x: (
            x["severity"],
            x["order_value"],
            x["delay_minutes"]
        ),
        reverse=True
    )

    top_exceptions = exceptions[:30]

    # ========================================================
    # BUSINESS IMPACT SUMMARY OUTPUT
    # ========================================================

    summary_rows = [

        {
            "impact_category": "TOTAL_OPERATIONS",
            "metric": "Total Orders",
            "value": total_orders,
            "financial_value": total_order_value,
            "percentage": 100.00
        },

        {
            "impact_category": "RISK",
            "metric": "Orders at Risk",
            "value": orders_at_risk,
            "financial_value": order_value_at_risk,
            "percentage": round(
                at_risk_rate,
                2
            )
        },

        {
            "impact_category": "RISK",
            "metric": "Critical Orders",
            "value": critical_orders,
            "financial_value": critical_order_value,
            "percentage": round(
                critical_value_pct,
                2
            )
        },

        {
            "impact_category": "DELIVERY",
            "metric": "Failed Deliveries",
            "value": failed_orders,
            "financial_value": failed_order_value,
            "percentage": round(
                failed_value_pct,
                2
            )
        },

        {
            "impact_category": "DELAY",
            "metric": "Severe Delays >60 min",
            "value": severe_delay_count,
            "financial_value": severe_delay_value,
            "percentage": round(
                severe_delay_value_pct,
                2
            )
        },

        {
            "impact_category": "PRIORITY",
            "metric": "High-Priority Orders at Risk",
            "value": high_priority_at_risk,
            "financial_value":
                high_priority_at_risk_value,
            "percentage": round(
                high_priority_at_risk
                / total_orders
                * 100,
                2
            )
        },

        {
            "impact_category": "FLEET",
            "metric": "Stopped Vehicle Events",
            "value": stopped_vehicle_count,
            "financial_value": 0,
            "percentage": round(
                stopped_vehicle_count
                / total_orders
                * 100,
                2
            )
        },

        {
            "impact_category": "FLEET",
            "metric": "Delayed Vehicle Events",
            "value": delayed_vehicle_count,
            "financial_value": 0,
            "percentage": round(
                delayed_vehicle_count
                / total_orders
                * 100,
                2
            )
        }
    ]

    summary_fieldnames = [
        "impact_category",
        "metric",
        "value",
        "financial_value",
        "percentage"
    ]

    with open(
        OUTPUT_FILE,
        "w",
        encoding="utf-8",
        newline=""
    ) as file:

        writer = csv.DictWriter(
            file,
            fieldnames=summary_fieldnames
        )

        writer.writeheader()
        writer.writerows(summary_rows)

    # ========================================================
    # EXCEPTION OUTPUT
    # ========================================================

    exception_fieldnames = [
        "shipment_id",
        "order_id",
        "destination_zone",
        "priority",
        "risk_level",
        "delay_minutes",
        "order_value",
        "vehicle_status",
        "delivery_status",
        "exception_type",
        "severity",
        "recommended_action"
    ]

    with open(
        EXCEPTION_FILE,
        "w",
        encoding="utf-8",
        newline=""
    ) as file:

        writer = csv.DictWriter(
            file,
            fieldnames=exception_fieldnames
        )

        writer.writeheader()
        writer.writerows(
            top_exceptions
        )

    # ========================================================
    # TOP BUSINESS EXPOSURE ZONES
    # ========================================================

    top_zone = (
        zone_results[0]
        if zone_results
        else None
    )

    # ========================================================
    # VALIDATION
    # ========================================================

    zone_order_total = sum(
        row["orders"]
        for row in zone_results
    )

    zone_value_total = sum(
        row["order_value"]
        for row in zone_results
    )

    exception_records = len(
        exceptions
    )

    validation_passed = (

        total_orders == 1000

        and orders_at_risk == 344

        and critical_orders == 225

        and failed_orders == 30

        and high_priority_at_risk == 42

        and abs(
            order_value_at_risk
            - 12776135.22
        ) < 0.01

        and abs(
            critical_order_value
            - 8475152.65
        ) < 0.01

        and zone_order_total == 1000

        and abs(
            zone_value_total
            - total_order_value
        ) < 0.01

        and exception_records == 1000
    )

    # ========================================================
    # VALIDATION REPORT
    # ========================================================

    validation_lines = [

        "REAL-TIME LOGISTICS CONTROL TOWER",
        "PHASE 7.5 BUSINESS IMPACT & EXCEPTION VALIDATION",
        "",

        "STATUS: COMPLETE",
        "",

        "BUSINESS SCALE",
        f"Total orders: {total_orders:,}",
        f"Total order value: ₹{total_order_value:,.2f}",
        "",

        "RISK EXPOSURE",
        f"Orders at Risk: {orders_at_risk:,}",
        f"Order Value at Risk: ₹{order_value_at_risk:,.2f}",
        f"At-Risk Order Rate: {at_risk_rate:.2f}%",
        f"At-Risk Value Share: {at_risk_value_pct:.2f}%",
        "",

        "CRITICAL EXPOSURE",
        f"Critical Orders: {critical_orders:,}",
        f"Critical Order Value: ₹{critical_order_value:,.2f}",
        f"Critical Value Share: {critical_value_pct:.2f}%",
        "",

        "DELIVERY FAILURE",
        f"Failed Deliveries: {failed_orders:,}",
        f"Failed Delivery Value: ₹{failed_order_value:,.2f}",
        f"Failed Value Share: {failed_value_pct:.2f}%",
        "",

        "SEVERE DELAY",
        f"Severe Delays >60 min: {severe_delay_count:,}",
        f"Severe Delay Value: ₹{severe_delay_value:,.2f}",
        f"Severe Delay Value Share: {severe_delay_value_pct:.2f}%",
        "",

        "PRIORITY EXPOSURE",
        f"High-Priority Orders: {high_priority_orders:,}",
        f"High-Priority Orders at Risk: "
        f"{high_priority_at_risk:,}",
        f"High-Priority Value at Risk: "
        f"₹{high_priority_at_risk_value:,.2f}",
        "",

        "FLEET EXCEPTIONS",
        f"Stopped Vehicle Records: "
        f"{stopped_vehicle_count:,}",
        f"Delayed Vehicle Records: "
        f"{delayed_vehicle_count:,}",
        "",

        "ZONE RECONCILIATION",
        f"Zone order total: {zone_order_total:,}",
        f"Zone value total: ₹{zone_value_total:,.2f}",
        "",

        "TOP BUSINESS-EXPOSURE ZONE",
        (
            f"Zone: {top_zone['zone']}"
            if top_zone
            else "Zone: N/A"
        ),
        (
            f"At-Risk Orders: "
            f"{top_zone['at_risk_orders']:,}"
            if top_zone
            else "At-Risk Orders: N/A"
        ),
        (
            f"At-Risk Value: "
            f"₹{top_zone['at_risk_value']:,.2f}"
            if top_zone
            else "At-Risk Value: N/A"
        ),
        (
            f"Risk Rate: "
            f"{top_zone['risk_rate_pct']:.2f}%"
            if top_zone
            else "Risk Rate: N/A"
        ),
        "",

        "EXCEPTION FRAMEWORK",
        "CRITICAL_DELAY → Immediate operations intervention",
        "CRITICAL_RISK → Immediate shipment review",
        "HIGH_PRIORITY_RISK → Prioritize intervention",
        "HIGH_RISK → Operations review",
        "VEHICLE_EXCEPTION → Fleet intervention",
        "SIGNIFICANT_DELAY → Monitor and investigate",
        "",

        "EXCEPTION RECORDS",
        f"Total classified exceptions: "
        f"{exception_records:,}",
        f"Top exceptions exported: "
        f"{len(top_exceptions):,}",
        "",

        "OUTPUT FILES",
        OUTPUT_FILE,
        EXCEPTION_FILE,
        VALIDATION_FILE,
        ""
    ]

    if validation_passed:

        validation_lines.append(
            "PHASE 7.5 STATUS: FROZEN"
        )

    else:

        validation_lines.append(
            "PHASE 7.5 STATUS: VALIDATION ISSUES DETECTED"
        )

    with open(
        VALIDATION_FILE,
        "w",
        encoding="utf-8"
    ) as file:

        file.write(
            "\n".join(validation_lines)
        )

    # ========================================================
    # DISPLAY RESULTS
    # ========================================================

    print("\n" + "=" * 70)
    print("BUSINESS IMPACT SUMMARY")
    print("=" * 70)

    print(
        f"Total Orders              : "
        f"{total_orders:,}"
    )

    print(
        f"Total Order Value         : "
        f"₹{total_order_value:,.2f}"
    )

    print(
        f"Orders at Risk            : "
        f"{orders_at_risk:,}"
    )

    print(
        f"Order Value at Risk       : "
        f"₹{order_value_at_risk:,.2f}"
    )

    print(
        f"At-Risk Order Rate        : "
        f"{at_risk_rate:.2f}%"
    )

    print(
        f"At-Risk Value Share       : "
        f"{at_risk_value_pct:.2f}%"
    )

    print(
        f"Critical Orders           : "
        f"{critical_orders:,}"
    )

    print(
        f"Critical Order Value      : "
        f"₹{critical_order_value:,.2f}"
    )

    print(
        f"Failed Deliveries         : "
        f"{failed_orders:,}"
    )

    print(
        f"Failed Delivery Value     : "
        f"₹{failed_order_value:,.2f}"
    )

    print(
        f"Severe Delays >60 min     : "
        f"{severe_delay_count:,}"
    )

    print(
        f"Severe Delay Value        : "
        f"₹{severe_delay_value:,.2f}"
    )

    print(
        f"High-Priority At Risk     : "
        f"{high_priority_at_risk:,}"
    )

    print(
        f"High-Priority Risk Value  : "
        f"₹{high_priority_at_risk_value:,.2f}"
    )

    print("\nZONE BUSINESS EXPOSURE")
    print("-" * 70)

    print(
        f"{'ZONE':<15}"
        f"{'ORDERS':>10}"
        f"{'AT RISK':>10}"
        f"{'RISK VALUE':>18}"
        f"{'RISK %':>10}"
    )

    for row in zone_results:

        print(
            f"{row['zone']:<15}"
            f"{row['orders']:>10,}"
            f"{row['at_risk_orders']:>10,}"
            f"₹{row['at_risk_value']:>16,.2f}"
            f"{row['risk_rate_pct']:>9.2f}%"
        )

    print("\nTOP EXCEPTIONS")
    print("-" * 70)

    for index, exception in enumerate(
        top_exceptions[:10],
        start=1
    ):

        print(
            f"{index:>2}. "
            f"{exception['shipment_id']} | "
            f"{exception['exception_type']} | "
            f"{exception['risk_level']} | "
            f"{exception['destination_zone']} | "
            f"₹{exception['order_value']:,.2f}"
        )

    print("\nVALIDATION")
    print("-" * 70)

    print(
        f"Total records             : "
        f"{total_orders:,}"
    )

    print(
        f"Orders at Risk            : "
        f"{orders_at_risk:,}"
    )

    print(
        f"Critical Orders           : "
        f"{critical_orders:,}"
    )

    print(
        f"Failed Deliveries         : "
        f"{failed_orders:,}"
    )

    print(
        f"High-Priority At Risk     : "
        f"{high_priority_at_risk:,}"
    )

    print(
        f"Zone order reconciliation : "
        f"{zone_order_total:,}"
    )

    print(
        f"Exception records         : "
        f"{exception_records:,}"
    )

    print("\nOUTPUT")
    print("-" * 70)

    print(
        f"Business Impact           : "
        f"{OUTPUT_FILE}"
    )

    print(
        f"Business Exceptions       : "
        f"{EXCEPTION_FILE}"
    )

    print(
        f"Validation Report         : "
        f"{VALIDATION_FILE}"
    )

    # ========================================================
    # FINAL RESULT
    # ========================================================

    if validation_passed:

        print("\n" + "=" * 70)
        print(
            "RESULT: PHASE 7.5 VALIDATION PASSED"
        )
        print("=" * 70)

    else:

        print("\n" + "=" * 70)
        print(
            "RESULT: VALIDATION ISSUES DETECTED"
        )
        print("=" * 70)


if __name__ == "__main__":
    main()