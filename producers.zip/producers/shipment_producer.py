import csv
import json
import time
from pathlib import Path

from kafka import KafkaProducer
from kafka.errors import KafkaError


# ============================================================
# REAL-TIME LOGISTICS CONTROL TOWER
# PHASE 5.7 — SHIPMENT PRODUCER
# ============================================================

BASE_DIR = Path(__file__).resolve().parent.parent

DATA_FILE = (
    BASE_DIR
    / "data"
    / "shipment_events.csv"
)

KAFKA_SERVER = "localhost:9092"

TOPIC = "shipment_events"

STREAM_DELAY_SECONDS = 0.03


# ============================================================
# KAFKA PRODUCER
# ============================================================

producer = KafkaProducer(

    bootstrap_servers=KAFKA_SERVER,

    key_serializer=lambda key:
        key.encode("utf-8"),

    value_serializer=lambda value:
        json.dumps(value).encode("utf-8"),

    acks="all"
)


# ============================================================
# CHECK DATA FILE
# ============================================================

if not DATA_FILE.exists():

    print(
        "ERROR: Data file not found:"
    )

    print(DATA_FILE)

    producer.close()

    raise SystemExit(1)


# ============================================================
# LOAD SHIPMENT DATA
# ============================================================

with open(
    DATA_FILE,
    "r",
    encoding="utf-8"
) as file:

    reader = csv.DictReader(file)

    rows = list(reader)


# ============================================================
# STARTUP INFORMATION
# ============================================================

print("=" * 70)
print("REAL-TIME LOGISTICS CONTROL TOWER")
print("SHIPMENT EVENT PRODUCER")
print("=" * 70)

print(
    f"Source file : {DATA_FILE}"
)

print(
    f"Kafka server: {KAFKA_SERVER}"
)

print(
    f"Kafka topic : {TOPIC}"
)

print(
    f"Records     : {len(rows):,}"
)

print("=" * 70)


# ============================================================
# REQUIRED FIELDS
# ============================================================

required_fields = [
    "event_id",
    "event_timestamp",
    "event_type",
    "shipment_id",
    "order_id",
    "warehouse_id",
    "zone",
    "vehicle_id"
]


# ============================================================
# STREAM EVENTS
# ============================================================

successful = 0
failed = 0


for row_number, row in enumerate(
    rows,
    start=1
):

    try:

        # ----------------------------------------------------
        # VALIDATE REQUIRED FIELDS
        # ----------------------------------------------------

        missing_fields = [

            field
            for field in required_fields

            if (
                field not in row
                or row[field] is None
                or str(row[field]).strip() == ""
            )
        ]


        if missing_fields:

            print(
                f"[SKIPPED] Row {row_number}: "
                f"Missing fields {missing_fields}"
            )

            failed += 1

            continue


        # ----------------------------------------------------
        # CREATE STREAMING EVENT
        # ----------------------------------------------------

        event = {

            "event_id":
                row["event_id"],

            "event_timestamp":
                row["event_timestamp"],

            "event_type":
                row["event_type"],

            "shipment_id":
                row["shipment_id"],

            "order_id":
                row["order_id"],

            "warehouse_id":
                row["warehouse_id"],

            "zone":
                row["zone"],

            "vehicle_id":
                row["vehicle_id"]
        }


        # ----------------------------------------------------
        # SEND EVENT TO KAFKA
        # ----------------------------------------------------

        future = producer.send(

            TOPIC,

            key=row["shipment_id"],

            value=event
        )


        # ----------------------------------------------------
        # WAIT FOR KAFKA ACKNOWLEDGEMENT
        # ----------------------------------------------------

        metadata = future.get(
            timeout=10
        )


        successful += 1


        # ----------------------------------------------------
        # DISPLAY PROGRESS
        # ----------------------------------------------------

        if (
            successful <= 10
            or successful % 500 == 0
        ):

            print(
                f"[SENT] "
                f"Shipment={row['shipment_id']} | "
                f"Event={row['event_type']} | "
                f"Partition={metadata.partition} | "
                f"Offset={metadata.offset}"
            )


        # ----------------------------------------------------
        # STREAMING DELAY
        # ----------------------------------------------------

        time.sleep(
            STREAM_DELAY_SECONDS
        )


    except KafkaError as error:

        failed += 1

        print(
            f"[KAFKA ERROR] "
            f"Row {row_number}: {error}"
        )


    except Exception as error:

        failed += 1

        print(
            f"[ERROR] "
            f"Row {row_number}: {error}"
        )


# ============================================================
# FLUSH AND CLOSE
# ============================================================

producer.flush()

producer.close()


# ============================================================
# FINAL SUMMARY
# ============================================================

print("\n" + "=" * 70)
print("SHIPMENT STREAMING COMPLETE")
print("=" * 70)

print(
    f"Successful events : {successful:,}"
)

print(
    f"Failed events     : {failed:,}"
)

print(
    f"Total processed   : "
    f"{successful + failed:,}"
)

print(
    f"Kafka topic       : {TOPIC}"
)

print("=" * 70)