import json
import mysql.connector
from kafka import KafkaConsumer


# ============================================================
# CONFIGURATION
# ============================================================

KAFKA_SERVER = "localhost:9092"

TOPICS = [
    "vehicle_events",
    "delivery_events"
]

DB_CONFIG = {
    "host": "127.0.0.1",
    "port": 3307,
    "user": "root",
    "password": "root",
    "database": "logistics_control_tower"
}


# ============================================================
# MYSQL CONNECTION
# ============================================================

def get_db_connection():
    return mysql.connector.connect(**DB_CONFIG)


# ============================================================
# VEHICLE EVENT → MYSQL
# ============================================================

def update_vehicle_event(event):

    shipment_id = event.get("shipment_id")

    if not shipment_id:
        print("[SKIP] Vehicle event has no shipment_id")
        return

    vehicle_status = event.get("vehicle_status")
    speed_kmh = event.get("speed_kmh", 0)
    zone = event.get("zone")

    conn = None
    cursor = None

    try:

        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute(
            """
            UPDATE logistics_analytics
            SET
                vehicle_status = %s,
                speed_kmh = %s,
                current_vehicle_zone = %s
            WHERE shipment_id = %s
            """,
            (
                vehicle_status,
                speed_kmh,
                zone,
                shipment_id
            )
        )

        conn.commit()

        print(
            f"[MYSQL] Vehicle updated | "
            f"Shipment={shipment_id} | "
            f"Status={vehicle_status} | "
            f"Zone={zone}"
        )

        if cursor.rowcount == 0:
            print(
                f"[WARNING] Shipment {shipment_id} "
                f"was not found in logistics_analytics"
            )

    except mysql.connector.Error as error:

        print(f"[MYSQL ERROR] {error}")

    finally:

        if cursor:
            cursor.close()

        if conn:
            conn.close()


# ============================================================
# DELIVERY EVENT → MYSQL
# ============================================================

def update_delivery_event(event):

    shipment_id = event.get("shipment_id")

    if not shipment_id:
        print("[SKIP] Delivery event has no shipment_id")
        return

    delay = float(event.get("delay_minutes", 0))

    delivery_status = event.get(
        "delivery_status",
        "DELIVERED"
    )

    # --------------------------------------------------------
    # RISK CALCULATION
    # --------------------------------------------------------

    if delivery_status == "FAILED":
        risk_level = "CRITICAL"
        risk_score = 4

    elif delay > 60:
        risk_level = "CRITICAL"
        risk_score = 4

    elif delay > 30:
        risk_level = "HIGH"
        risk_score = 3

    elif delay > 15:
        risk_level = "MEDIUM"
        risk_score = 2

    else:
        risk_level = "LOW"
        risk_score = 1

    is_at_risk = "YES" if risk_score >= 3 else "NO"

    is_critical = (
        "YES"
        if risk_level == "CRITICAL"
        else "NO"
    )

    conn = None
    cursor = None

    try:

        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute(
            """
            UPDATE logistics_analytics
            SET
                delay_minutes = %s,
                delivery_status = %s,
                risk_level = %s,
                risk_score = %s,
                is_at_risk = %s,
                is_critical = %s
            WHERE shipment_id = %s
            """,
            (
                delay,
                delivery_status,
                risk_level,
                risk_score,
                is_at_risk,
                is_critical,
                shipment_id
            )
        )

        conn.commit()

        print(
            f"[MYSQL] Delivery updated | "
            f"Shipment={shipment_id} | "
            f"Delay={delay} min | "
            f"Risk={risk_level}"
        )

        if cursor.rowcount == 0:
            print(
                f"[WARNING] Shipment {shipment_id} "
                f"was not found in logistics_analytics"
            )

    except mysql.connector.Error as error:

        print(f"[MYSQL ERROR] {error}")

    finally:

        if cursor:
            cursor.close()

        if conn:
            conn.close()


# ============================================================
# MAIN LIVE CONSUMER
# ============================================================

def main():

    print("=" * 70)
    print("REAL-TIME LOGISTICS CONTROL TOWER")
    print("LIVE KAFKA → MYSQL CONSUMER")
    print("=" * 70)

    print("\nConnecting to Kafka...")

    consumer = KafkaConsumer(
        *TOPICS,
        bootstrap_servers=KAFKA_SERVER,

        value_deserializer=lambda x: json.loads(
            x.decode("utf-8")
        ),

        auto_offset_reset="latest",

        enable_auto_commit=True,

        group_id="logistics-live-demo"
    )

    print("\nConnected to Kafka")

    print("Listening for live events...")

    print("\nTopics:")

    for topic in TOPICS:
        print(f"  - {topic}")

    print("\n" + "-" * 70)
    print("WAITING FOR LIVE EVENTS")
    print("-" * 70)

    try:

        for message in consumer:

            event = message.value

            topic = message.topic

            print("\n[KAFKA EVENT RECEIVED]")
            print(f"Topic     : {topic}")
            print(
                f"Event ID  : "
                f"{event.get('event_id', 'N/A')}"
            )
            print(
                f"Shipment  : "
                f"{event.get('shipment_id', 'N/A')}"
            )

            # ------------------------------------------------
            # VEHICLE EVENT
            # ------------------------------------------------

            if topic == "vehicle_events":

                update_vehicle_event(event)

            # ------------------------------------------------
            # DELIVERY EVENT
            # ------------------------------------------------

            elif topic == "delivery_events":

                update_delivery_event(event)

            print("-" * 70)

    except KeyboardInterrupt:

        print("\n")
        print("=" * 70)
        print("LIVE CONSUMER STOPPED")
        print("=" * 70)

    finally:

        consumer.close()


# ============================================================
# RUN
# ============================================================

if __name__ == "__main__":
    main()