import csv
import os


# ============================================================
# PROJECT PATHS
# ============================================================

BASE_DIR = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)

ANALYTICS_DIR = os.path.join(
    BASE_DIR,
    "analytics"
)

ANALYTICAL_FILE = os.path.join(
    ANALYTICS_DIR,
    "logistics_analytical_dataset.csv"
)

ZONE_FILE = os.path.join(
    ANALYTICS_DIR,
    "zone_performance.csv"
)

DELAY_FILE = os.path.join(
    ANALYTICS_DIR,
    "delay_analysis.csv"
)

RISK_FILE = os.path.join(
    ANALYTICS_DIR,
    "risk_summary.csv"
)

MATRIX_FILE = os.path.join(
    ANALYTICS_DIR,
    "priority_risk_matrix.csv"
)

IMPACT_FILE = os.path.join(
    ANALYTICS_DIR,
    "business_impact_summary.csv"
)

EXCEPTION_FILE = os.path.join(
    ANALYTICS_DIR,
    "business_exceptions.csv"
)

OUTPUT_FILE = os.path.join(
    ANALYTICS_DIR,
    "PHASE7_VALIDATION.txt"
)


# ============================================================
# HELPERS
# ============================================================

def read_csv_file(filepath):

    with open(
        filepath,
        "r",
        encoding="utf-8-sig",
        newline=""
    ) as file:

        return list(csv.DictReader(file))


def to_float(value):

    try:
        return float(value or 0)
    except (ValueError, TypeError):
        return 0.0


def check_file(filepath):

    return os.path.exists(filepath)


# ============================================================
# MAIN
# ============================================================

def main():

    print("=" * 70)
    print("PHASE 7.6 - ANALYTICS VALIDATION & PHASE 7 FREEZE")
    print("=" * 70)

    print("\nChecking Phase 7 analytical outputs...")

    required_files = {
        "Analytical Dataset": ANALYTICAL_FILE,
        "Zone Performance": ZONE_FILE,
        "Delay Analysis": DELAY_FILE,
        "Risk Summary": RISK_FILE,
        "Priority-Risk Matrix": MATRIX_FILE,
        "Business Impact": IMPACT_FILE,
        "Business Exceptions": EXCEPTION_FILE
    }

    missing_files = []

    for name, filepath in required_files.items():

        if check_file(filepath):

            print(
                f"[OK] {name}"
            )

        else:

            print(
                f"[MISSING] {name}"
            )

            missing_files.append(name)

    if missing_files:

        print("\nERROR: Required Phase 7 output files are missing.")

        for item in missing_files:
            print(
                f"- {item}"
            )

        return

    # ========================================================
    # LOAD DATASETS
    # ========================================================

    analytical = read_csv_file(
        ANALYTICAL_FILE
    )

    zone_data = read_csv_file(
        ZONE_FILE
    )

    delay_data = read_csv_file(
        DELAY_FILE
    )

    risk_data = read_csv_file(
        RISK_FILE
    )

    matrix_data = read_csv_file(
        MATRIX_FILE
    )

    impact_data = read_csv_file(
        IMPACT_FILE
    )

    exceptions = read_csv_file(
        EXCEPTION_FILE
    )

    # ========================================================
    # PHASE 7.1 BASELINE
    # ========================================================

    total_records = len(
        analytical
    )

    total_order_value = sum(
        to_float(
            row.get("order_value")
        )
        for row in analytical
    )

    valid_duration_count = sum(
        1
        for row in analytical
        if row.get("duration_valid") == "YES"
    )

    invalid_duration_count = sum(
        1
        for row in analytical
        if row.get("duration_valid") != "YES"
    )

    missing_risk_count = sum(
        1
        for row in analytical
        if not row.get("risk_level")
    )

    # ========================================================
    # RISK DISTRIBUTION
    # ========================================================

    risk_counts = {
        "LOW": 0,
        "MEDIUM": 0,
        "HIGH": 0,
        "CRITICAL": 0
    }

    for row in analytical:

        risk = (
            row.get("risk_level")
            or ""
        ).upper()

        if risk in risk_counts:
            risk_counts[risk] += 1

    orders_at_risk = (
        risk_counts["HIGH"]
        + risk_counts["CRITICAL"]
    )

    critical_orders = (
        risk_counts["CRITICAL"]
    )

    order_value_at_risk = sum(
        to_float(
            row.get("order_value")
        )
        for row in analytical
        if row.get("risk_level")
        in ["HIGH", "CRITICAL"]
    )

    critical_order_value = sum(
        to_float(
            row.get("order_value")
        )
        for row in analytical
        if row.get("risk_level")
        == "CRITICAL"
    )

    # ========================================================
    # DELIVERY METRICS
    # ========================================================

    delayed_records = [
        row
        for row in analytical
        if to_float(
            row.get("delay_minutes")
        ) > 0
    ]

    on_time_records = [
        row
        for row in analytical
        if to_float(
            row.get("delay_minutes")
        ) <= 0
    ]

    failed_records = [
        row
        for row in analytical
        if row.get(
            "delivery_status",
            ""
        ).upper() == "FAILED"
    ]

    delayed_count = len(
        delayed_records
    )

    on_time_count = len(
        on_time_records
    )

    failed_count = len(
        failed_records
    )

    average_delay = (
        sum(
            to_float(
                row.get("delay_minutes")
            )
            for row in delayed_records
        )
        / delayed_count
        if delayed_count
        else 0
    )

    # ========================================================
    # ZONE RECONCILIATION
    # ========================================================

    zone_order_total = sum(
        int(
            float(
                row.get("orders", 0)
            )
        )
        for row in zone_data
    )

    zone_value_total = sum(
        to_float(
            row.get("order_value")
        )
        for row in zone_data
    )

    zone_at_risk_total = sum(
        int(
            float(
                row.get("at_risk_shipments", 0)
            )
        )
        for row in zone_data
    )

    zone_critical_total = sum(
        int(
            float(
                row.get("critical_shipments", 0)
            )
        )
        for row in zone_data
    )

    # ========================================================
    # RISK OUTPUT RECONCILIATION
    # ========================================================

    risk_output_total = sum(
        int(
            float(
                row.get("orders", 0)
            )
        )
        for row in risk_data
    )

    risk_output_value = sum(
        to_float(
            row.get("order_value")
        )
        for row in risk_data
    )

    # ========================================================
    # PRIORITY-RISK MATRIX RECONCILIATION
    # ========================================================

    matrix_total = sum(
        int(
            float(
                row.get("orders", 0)
            )
        )
        for row in matrix_data
    )

    matrix_value = sum(
        to_float(
            row.get("order_value")
        )
        for row in matrix_data
    )

    # ========================================================
    # HIGH-PRIORITY RISK
    # ========================================================

    high_priority_risk = [
        row
        for row in analytical
        if (
            row.get("priority", "").upper()
            == "HIGH"
            and row.get("risk_level", "").upper()
            in ["HIGH", "CRITICAL"]
        )
    ]

    high_priority_risk_count = len(
        high_priority_risk
    )

    high_priority_risk_value = sum(
        to_float(
            row.get("order_value")
        )
        for row in high_priority_risk
    )

    # ========================================================
    # BUSINESS IMPACT OUTPUT CHECK
    # ========================================================

    impact_metrics = {
        row.get("metric"): row
        for row in impact_data
    }

    impact_at_risk = to_float(
        impact_metrics.get(
            "Orders at Risk",
            {}
        ).get("value")
    )

    impact_critical = to_float(
        impact_metrics.get(
            "Critical Orders",
            {}
        ).get("value")
    )

    impact_failed = to_float(
        impact_metrics.get(
            "Failed Deliveries",
            {}
        ).get("value")
    )

    impact_high_priority = to_float(
        impact_metrics.get(
            "High-Priority Orders at Risk",
            {}
        ).get("value")
    )

    # ========================================================
    # EXCEPTION RECONCILIATION
    # ========================================================

    exception_count = len(
        exceptions
    )

    # ========================================================
    # VALIDATION TESTS
    # ========================================================

    tests = []

    def add_test(name, passed):

        tests.append(
            {
                "name": name,
                "passed": bool(passed)
            }
        )

    # 7.1
    add_test(
        "Analytical records = 1,000",
        total_records == 1000
    )

    add_test(
        "Valid durations = 1,000",
        valid_duration_count == 1000
    )

    add_test(
        "Invalid durations = 0",
        invalid_duration_count == 0
    )

    add_test(
        "All records have risk classification",
        missing_risk_count == 0
    )

    # Risk
    add_test(
        "LOW risk = 337",
        risk_counts["LOW"] == 337
    )

    add_test(
        "MEDIUM risk = 319",
        risk_counts["MEDIUM"] == 319
    )

    add_test(
        "HIGH risk = 119",
        risk_counts["HIGH"] == 119
    )

    add_test(
        "CRITICAL risk = 225",
        risk_counts["CRITICAL"] == 225
    )

    add_test(
        "Orders at Risk = 344",
        orders_at_risk == 344
    )

    add_test(
        "Critical Orders = 225",
        critical_orders == 225
    )

    add_test(
        "Order Value at Risk = ₹12,776,135.22",
        abs(
            order_value_at_risk
            - 12776135.22
        ) < 0.01
    )

    add_test(
        "Critical Order Value = ₹8,475,152.65",
        abs(
            critical_order_value
            - 8475152.65
        ) < 0.01
    )

    # Delivery
    add_test(
        "Delayed deliveries = 951",
        delayed_count == 951
    )

    add_test(
        "On-time deliveries = 49",
        on_time_count == 49
    )

    add_test(
        "Failed deliveries = 30",
        failed_count == 30
    )

    add_test(
        "Average delay among delayed deliveries = 29.93 min",
        abs(
            average_delay
            - 29.93
        ) < 0.01
    )

    # Zone
    add_test(
        "Zone orders reconcile to 1,000",
        zone_order_total == 1000
    )

    add_test(
        "Zone order value reconciles",
        abs(
            zone_value_total
            - total_order_value
        ) < 0.01
    )

    add_test(
        "Zone at-risk shipments = 344",
        zone_at_risk_total == 344
    )

    add_test(
        "Zone critical shipments = 225",
        zone_critical_total == 225
    )

    # Risk outputs
    add_test(
        "Risk summary records = 1,000",
        risk_output_total == 1000
    )

    add_test(
        "Risk summary value reconciles",
        abs(
            risk_output_value
            - total_order_value
        ) < 0.01
    )

    # Matrix
    add_test(
        "Priority-risk matrix records = 1,000",
        matrix_total == 1000
    )

    add_test(
        "Priority-risk matrix value reconciles",
        abs(
            matrix_value
            - total_order_value
        ) < 0.01
    )

    # High priority
    add_test(
        "High-priority orders at risk = 42",
        high_priority_risk_count == 42
    )

    add_test(
        "High-priority risk value = ₹1,436,316.88",
        abs(
            high_priority_risk_value
            - 1436316.88
        ) < 0.01
    )

    # Business impact
    add_test(
        "Business impact Orders at Risk = 344",
        impact_at_risk == 344
    )

    add_test(
        "Business impact Critical Orders = 225",
        impact_critical == 225
    )

    add_test(
        "Business impact Failed Deliveries = 30",
        impact_failed == 30
    )

    add_test(
        "Business impact High-Priority At Risk = 42",
        impact_high_priority == 42
    )

    # Exceptions
    add_test(
    "Top exception records exported = 30",
    exception_count == 30
)

    # ========================================================
    # FINAL RESULT
    # ========================================================

    passed_tests = sum(
        1
        for test in tests
        if test["passed"]
    )

    total_tests = len(
        tests
    )

    all_passed = (
        passed_tests == total_tests
    )

    # ========================================================
    # CREATE FINAL PHASE 7 REPORT
    # ========================================================

    validation_lines = [

        "============================================================",
        "REAL-TIME LOGISTICS CONTROL TOWER",
        "PHASE 7 - ANALYTICS & RISK INTELLIGENCE",
        "FINAL VALIDATION & FREEZE",
        "============================================================",
        "",

        "PHASE 7 STATUS",
        (
            "FROZEN - ALL VALIDATION TESTS PASSED"
            if all_passed
            else "VALIDATION ISSUES DETECTED"
        ),
        "",

        "PHASE 7.1 - ANALYTICAL DATASET",
        f"Analytical records: {total_records:,}",
        f"Valid durations: {valid_duration_count:,}",
        f"Invalid durations: {invalid_duration_count:,}",
        "",

        "PHASE 7.2 - ZONE PERFORMANCE",
        f"Zones identified: {len(zone_data):,}",
        f"Zone orders: {zone_order_total:,}",
        f"Zone order value: ₹{zone_value_total:,.2f}",
        f"Zone at-risk shipments: {zone_at_risk_total:,}",
        f"Zone critical shipments: {zone_critical_total:,}",
        "",

        "PHASE 7.3 - DELIVERY & DELAY",
        f"Delayed deliveries: {delayed_count:,}",
        f"On-time deliveries: {on_time_count:,}",
        f"Failed deliveries: {failed_count:,}",
        f"Average delay among delayed deliveries: "
        f"{average_delay:.2f} minutes",
        "",

        "PHASE 7.4 - RISK & PRIORITY",
        f"LOW: {risk_counts['LOW']:,}",
        f"MEDIUM: {risk_counts['MEDIUM']:,}",
        f"HIGH: {risk_counts['HIGH']:,}",
        f"CRITICAL: {risk_counts['CRITICAL']:,}",
        f"Orders at Risk: {orders_at_risk:,}",
        f"Order Value at Risk: ₹{order_value_at_risk:,.2f}",
        f"Critical Orders: {critical_orders:,}",
        f"Critical Order Value: ₹{critical_order_value:,.2f}",
        f"High-Priority Orders at Risk: "
        f"{high_priority_risk_count:,}",
        f"High-Priority Value at Risk: "
        f"₹{high_priority_risk_value:,.2f}",
        "",

        "PHASE 7.5 - BUSINESS IMPACT",
        f"Business impact records: {len(impact_data):,}",
        f"Exception records: {exception_count:,}",
        "",

        "RECONCILIATION",
        f"Risk summary records: {risk_output_total:,}",
        f"Priority-risk matrix records: {matrix_total:,}",
        f"Risk summary value: ₹{risk_output_value:,.2f}",
        f"Priority-risk matrix value: ₹{matrix_value:,.2f}",
        "",

        "VALIDATION TESTS",
        f"Tests passed: {passed_tests}/{total_tests}",
        ""
    ]

    for test in tests:

        status = (
            "PASS"
            if test["passed"]
            else "FAIL"
        )

        validation_lines.append(
            f"[{status}] {test['name']}"
        )

    validation_lines.extend(
        [
            "",
            "============================================================",
            (
                "PHASE 7 FINAL STATUS: FROZEN"
                if all_passed
                else "PHASE 7 FINAL STATUS: NOT FROZEN"
            ),
            "============================================================",
            "",
            "PHASE 7 ANALYTICAL CHAIN:",
            "EVENT → METRIC → KPI → RISK → BUSINESS IMPACT → DECISION",
            "",
            "NEXT PHASE:",
            "PHASE 8 - DATA STORAGE / INTEGRATION",
            ""
        ]
    )

    with open(
        OUTPUT_FILE,
        "w",
        encoding="utf-8"
    ) as file:

        file.write(
            "\n".join(validation_lines)
        )

    # ========================================================
    # TERMINAL OUTPUT
    # ========================================================

    print("\n" + "=" * 70)
    print("PHASE 7 FINAL RECONCILIATION")
    print("=" * 70)

    print(
        f"Analytical records       : "
        f"{total_records:,}"
    )

    print(
        f"Zone records             : "
        f"{zone_order_total:,}"
    )

    print(
        f"Risk records             : "
        f"{risk_output_total:,}"
    )

    print(
        f"Matrix records           : "
        f"{matrix_total:,}"
    )

    print(
        f"Exception records        : "
        f"{exception_count:,}"
    )

    print(
        f"Orders at Risk           : "
        f"{orders_at_risk:,}"
    )

    print(
        f"Order Value at Risk      : "
        f"₹{order_value_at_risk:,.2f}"
    )

    print(
        f"Critical Orders          : "
        f"{critical_orders:,}"
    )

    print(
        f"Critical Order Value     : "
        f"₹{critical_order_value:,.2f}"
    )

    print(
        f"High-Priority At Risk    : "
        f"{high_priority_risk_count:,}"
    )

    print(
        f"Failed Deliveries        : "
        f"{failed_count:,}"
    )

    print(
        f"Average Delay            : "
        f"{average_delay:.2f} minutes"
    )

    print("\nVALIDATION TESTS")
    print("-" * 70)

    for test in tests:

        status = (
            "PASS"
            if test["passed"]
            else "FAIL"
        )

        print(
            f"[{status}] {test['name']}"
        )

    print("\nOUTPUT")
    print("-" * 70)

    print(
        f"Final Phase 7 Report    : "
        f"{OUTPUT_FILE}"
    )

    if all_passed:

        print("\n" + "=" * 70)
        print(
            "RESULT: PHASE 7 VALIDATION PASSED"
        )
        print(
            "PHASE 7 STATUS: FROZEN"
        )
        print("=" * 70)

    else:

        print("\n" + "=" * 70)
        print(
            "RESULT: PHASE 7 VALIDATION FAILED"
        )
        print(
            "PHASE 7 STATUS: NOT FROZEN"
        )
        print("=" * 70)


if __name__ == "__main__":
    main()