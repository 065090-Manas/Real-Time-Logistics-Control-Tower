from consumer import (
    validate_event,
    route_event,
    parse_timestamp,
    calculate_risk_level,
    get_risk_score
)


# ============================================================
# TEST COUNTERS
# ============================================================

passed = 0
failed = 0


def test(name, condition):

    global passed
    global failed

    if condition:

        print(f"[PASS] {name}")
        passed += 1

    else:

        print(f"[FAIL] {name}")
        failed += 1


# ============================================================
# 1. EVENT VALIDATION TEST
# ============================================================

valid_order = {
    "event_id": "ORD-EVT-TEST",
    "event_timestamp": "2026-09-06 09:36:00",
    "event_type": "ORDER_CREATED",
    "order_id": "ORDTEST001",
    "customer_id": "CUSTTEST",
    "origin_zone": "Delhi",
    "destination_zone": "Gurgaon",
    "warehouse_id": "WH001",
    "order_value": 10000,
    "priority": "Standard"
}

is_valid, message = validate_event(
    "order_events",
    valid_order
)

test(
    "Valid order event accepted",
    is_valid
)


# ============================================================
# 2. INVALID EVENT TEST
# ============================================================

invalid_order = {
    "event_id": "ORD-EVT-INVALID"
}

is_valid, message = validate_event(
    "order_events",
    invalid_order
)

test(
    "Incomplete event rejected",
    not is_valid
)


# ============================================================
# 3. ROUTING TEST
# ============================================================

test(
    "Order topic routing",
    route_event("order_events") == "ORDER"
)

test(
    "Shipment topic routing",
    route_event("shipment_events") == "SHIPMENT"
)

test(
    "Vehicle topic routing",
    route_event("vehicle_events") == "VEHICLE"
)

test(
    "Delivery topic routing",
    route_event("delivery_events") == "DELIVERY"
)


# ============================================================
# 4. UNKNOWN TOPIC TEST
# ============================================================

test(
    "Unknown topic identified",
    route_event("unknown_topic") == "UNKNOWN"
)


# ============================================================
# 5. TIMESTAMP TEST
# ============================================================

timestamp = parse_timestamp(
    "2026-09-06 09:36:00"
)

test(
    "Timestamp parsed successfully",
    timestamp.year == 2026
    and timestamp.month == 9
    and timestamp.day == 6
)


# ============================================================
# 6. DELIVERY RISK TEST
# ============================================================

test(
    "Low risk detected",
    calculate_risk_level(
        5,
        "MOVING",
        "Standard",
        "DELIVERED"
    ) == "LOW"
)


test(
    "Medium risk detected",
    calculate_risk_level(
        25,
        "MOVING",
        "Standard",
        "DELIVERED"
    ) == "MEDIUM"
)


test(
    "High risk detected",
    calculate_risk_level(
        45,
        "MOVING",
        "Standard",
        "DELIVERED"
    ) == "HIGH"
)


test(
    "Critical risk detected",
    calculate_risk_level(
        90,
        "MOVING",
        "Standard",
        "DELIVERED"
    ) == "CRITICAL"
)


# ============================================================
# 7. VEHICLE CONDITION TEST
# ============================================================

test(
    "Stopped vehicle increases risk",
    calculate_risk_level(
        20,
        "STOPPED",
        "Standard",
        "DELIVERED"
    ) == "HIGH"
)


# ============================================================
# 8. HIGH PRIORITY TEST
# ============================================================

test(
    "High priority shipment increases risk",
    calculate_risk_level(
        20,
        "MOVING",
        "High",
        "DELIVERED"
    ) == "HIGH"
)


# ============================================================
# 9. FAILED DELIVERY TEST
# ============================================================

test(
    "Failed delivery becomes critical",
    calculate_risk_level(
        5,
        "MOVING",
        "Standard",
        "FAILED"
    ) == "CRITICAL"
)


# ============================================================
# 10. RISK SCORE TEST
# ============================================================

test(
    "LOW risk score",
    get_risk_score("LOW") == 1
)

test(
    "MEDIUM risk score",
    get_risk_score("MEDIUM") == 2
)

test(
    "HIGH risk score",
    get_risk_score("HIGH") == 3
)

test(
    "CRITICAL risk score",
    get_risk_score("CRITICAL") == 4
)


# ============================================================
# FINAL TEST RESULT
# ============================================================

print()
print("=" * 60)
print("PHASE 6.9 STREAM PROCESSOR TEST RESULTS")
print("=" * 60)

print(
    f"Tests Passed : {passed}"
)

print(
    f"Tests Failed : {failed}"
)

print(
    f"Total Tests  : {passed + failed}"
)

print("=" * 60)

if failed == 0:

    print(
        "RESULT: ALL TESTS PASSED"
    )

else:

    print(
        "RESULT: TEST FAILURES DETECTED"
    )

print("=" * 60)