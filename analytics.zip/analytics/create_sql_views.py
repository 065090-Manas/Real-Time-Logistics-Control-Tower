import mysql.connector


# ============================================================
# MYSQL CONFIGURATION
# ============================================================

MYSQL_HOST = "127.0.0.1"
MYSQL_PORT = 3307
MYSQL_USER = "root"

DATABASE = "logistics_control_tower"


# ============================================================
# SQL VIEWS
# ============================================================

VIEWS = {

    # --------------------------------------------------------
    # 1. EXECUTIVE KPI VIEW
    # --------------------------------------------------------

    "vw_executive_kpis": """
    CREATE OR REPLACE VIEW vw_executive_kpis AS

    SELECT

        COUNT(*) AS total_orders,

        ROUND(
            SUM(order_value),
            2
        ) AS total_order_value,

        ROUND(
            AVG(
                CASE
                    WHEN delay_minutes > 0
                    THEN delay_minutes
                END
            ),
            2
        ) AS average_delay_minutes,

        ROUND(
            AVG(delivery_time_minutes),
            2
        ) AS average_delivery_time_minutes,

        SUM(
            CASE
                WHEN delay_minutes > 0
                THEN 1
                ELSE 0
            END
        ) AS delayed_orders,

        SUM(
            CASE
                WHEN delay_minutes <= 0
                THEN 1
                ELSE 0
            END
        ) AS on_time_orders,

        ROUND(
            SUM(
                CASE
                    WHEN delay_minutes <= 0
                    THEN 1
                    ELSE 0
                END
            )
            / COUNT(*) * 100,
            2
        ) AS on_time_rate_pct,

        SUM(
            CASE
                WHEN delivery_status = 'FAILED'
                THEN 1
                ELSE 0
            END
        ) AS failed_deliveries,

        SUM(
            CASE
                WHEN risk_level IN ('HIGH', 'CRITICAL')
                THEN 1
                ELSE 0
            END
        ) AS orders_at_risk,

        ROUND(
            SUM(
                CASE
                    WHEN risk_level IN ('HIGH', 'CRITICAL')
                    THEN order_value
                    ELSE 0
                END
            ),
            2
        ) AS order_value_at_risk,

        SUM(
            CASE
                WHEN risk_level = 'CRITICAL'
                THEN 1
                ELSE 0
            END
        ) AS critical_orders,

        ROUND(
            SUM(
                CASE
                    WHEN risk_level = 'CRITICAL'
                    THEN order_value
                    ELSE 0
                END
            ),
            2
        ) AS critical_order_value,

        SUM(
            CASE
                WHEN risk_level = 'HIGH'
                THEN 1
                ELSE 0
            END
        ) AS high_risk_orders,

        SUM(
            CASE
                WHEN delay_minutes > 60
                THEN 1
                ELSE 0
            END
        ) AS severe_delay_orders

    FROM logistics_analytics;
    """,

    # --------------------------------------------------------
    # 2. ZONE PERFORMANCE VIEW
    # --------------------------------------------------------

    "vw_zone_performance": """
    CREATE OR REPLACE VIEW vw_zone_performance AS

    SELECT

        destination_zone AS zone,

        COUNT(*) AS orders,

        ROUND(
            SUM(order_value),
            2
        ) AS order_value,

        ROUND(
            AVG(delay_minutes),
            2
        ) AS average_delay_minutes,

        ROUND(
            AVG(
                CASE
                    WHEN delay_minutes > 0
                    THEN delay_minutes
                END
            ),
            2
        ) AS average_delay_delayed_orders,

        SUM(
            CASE
                WHEN delay_minutes <= 0
                THEN 1
                ELSE 0
            END
        ) AS on_time_orders,

        ROUND(
            SUM(
                CASE
                    WHEN delay_minutes <= 0
                    THEN 1
                    ELSE 0
                END
            )
            / COUNT(*) * 100,
            2
        ) AS on_time_rate_pct,

        SUM(
            CASE
                WHEN risk_level IN ('HIGH', 'CRITICAL')
                THEN 1
                ELSE 0
            END
        ) AS at_risk_orders,

        ROUND(
            SUM(
                CASE
                    WHEN risk_level IN ('HIGH', 'CRITICAL')
                    THEN order_value
                    ELSE 0
                END
            ),
            2
        ) AS at_risk_value,

        SUM(
            CASE
                WHEN risk_level = 'CRITICAL'
                THEN 1
                ELSE 0
            END
        ) AS critical_orders,

        SUM(
            CASE
                WHEN delivery_status = 'FAILED'
                THEN 1
                ELSE 0
            END
        ) AS failed_deliveries,

        SUM(
            CASE
                WHEN delay_minutes > 60
                THEN 1
                ELSE 0
            END
        ) AS severe_delays

    FROM logistics_analytics

    GROUP BY destination_zone;
    """,

    # --------------------------------------------------------
    # 3. RISK DISTRIBUTION VIEW
    # --------------------------------------------------------

    "vw_risk_distribution": """
    CREATE OR REPLACE VIEW vw_risk_distribution AS

    SELECT

        risk_level,

        COUNT(*) AS orders,

        ROUND(
            COUNT(*) / (
                SELECT COUNT(*)
                FROM logistics_analytics
            ) * 100,
            2
        ) AS percentage_of_orders,

        ROUND(
            SUM(order_value),
            2
        ) AS order_value,

        ROUND(
            SUM(order_value) / (
                SELECT SUM(order_value)
                FROM logistics_analytics
            ) * 100,
            2
        ) AS percentage_of_value

    FROM logistics_analytics

    GROUP BY risk_level

    ORDER BY
        CASE risk_level
            WHEN 'LOW' THEN 1
            WHEN 'MEDIUM' THEN 2
            WHEN 'HIGH' THEN 3
            WHEN 'CRITICAL' THEN 4
            ELSE 5
        END;
    """,

    # --------------------------------------------------------
    # 4. PRIORITY-RISK VIEW
    # --------------------------------------------------------

    "vw_priority_risk": """
    CREATE OR REPLACE VIEW vw_priority_risk AS

    SELECT

        priority,

        risk_level,

        COUNT(*) AS orders,

        ROUND(
            SUM(order_value),
            2
        ) AS order_value,

        ROUND(
            AVG(delay_minutes),
            2
        ) AS average_delay_minutes,

        SUM(
            CASE
                WHEN delay_minutes > 0
                THEN 1
                ELSE 0
            END
        ) AS delayed_orders,

        ROUND(
            SUM(
                CASE
                    WHEN delay_minutes > 0
                    THEN 1
                    ELSE 0
                END
            )
            / COUNT(*) * 100,
            2
        ) AS delayed_rate_pct

    FROM logistics_analytics

    GROUP BY
        priority,
        risk_level

    ORDER BY
        CASE priority
            WHEN 'HIGH' THEN 1
            WHEN 'EXPRESS' THEN 2
            WHEN 'STANDARD' THEN 3
            ELSE 4
        END,

        CASE risk_level
            WHEN 'CRITICAL' THEN 1
            WHEN 'HIGH' THEN 2
            WHEN 'MEDIUM' THEN 3
            WHEN 'LOW' THEN 4
            ELSE 5
        END;
    """,

    # --------------------------------------------------------
    # 5. DELAY PERFORMANCE VIEW
    # --------------------------------------------------------

    "vw_delay_performance": """
    CREATE OR REPLACE VIEW vw_delay_performance AS

    SELECT

        CASE

            WHEN delay_minutes <= 0
                THEN 'On Time'

            WHEN delay_minutes <= 15
                THEN '1-15 min'

            WHEN delay_minutes <= 30
                THEN '16-30 min'

            WHEN delay_minutes <= 60
                THEN '31-60 min'

            ELSE '60+ min'

        END AS delay_category,

        COUNT(*) AS orders,

        ROUND(
            AVG(delay_minutes),
            2
        ) AS average_delay_minutes,

        ROUND(
            SUM(order_value),
            2
        ) AS order_value

    FROM logistics_analytics

    GROUP BY

        CASE

            WHEN delay_minutes <= 0
                THEN 'On Time'

            WHEN delay_minutes <= 15
                THEN '1-15 min'

            WHEN delay_minutes <= 30
                THEN '16-30 min'

            WHEN delay_minutes <= 60
                THEN '31-60 min'

            ELSE '60+ min'

        END

    ORDER BY
        CASE

            WHEN delay_category = 'On Time'
                THEN 1

            WHEN delay_category = '1-15 min'
                THEN 2

            WHEN delay_category = '16-30 min'
                THEN 3

            WHEN delay_category = '31-60 min'
                THEN 4

            ELSE 5

        END;
    """,

    # --------------------------------------------------------
    # 6. INTERVENTION CANDIDATES VIEW
    # --------------------------------------------------------

    "vw_intervention_candidates": """
    CREATE OR REPLACE VIEW vw_intervention_candidates AS

    SELECT

        shipment_id,

        order_id,

        destination_zone AS zone,

        priority,

        risk_level,

        delay_minutes,

        order_value,

        vehicle_status,

        delivery_status,

        risk_score,

        is_at_risk,

        is_critical,

        CASE

            WHEN delivery_status = 'FAILED'
                THEN 'Immediate delivery recovery'

            WHEN risk_level = 'CRITICAL'
                 AND delay_minutes > 60
                THEN 'Immediate operations intervention'

            WHEN risk_level = 'CRITICAL'
                THEN 'Immediate shipment review'

            WHEN risk_level = 'HIGH'
                 AND priority = 'HIGH'
                THEN 'Prioritize operational intervention'

            WHEN risk_level = 'HIGH'
                THEN 'Operations review required'

            WHEN vehicle_status IN ('STOPPED', 'DELAYED')
                THEN 'Fleet review and intervention'

            WHEN delay_minutes > 30
                THEN 'Monitor and investigate delay'

            ELSE 'Continue monitoring'

        END AS recommended_action

    FROM logistics_analytics

    WHERE risk_level IN ('HIGH', 'CRITICAL')

    ORDER BY

        CASE risk_level
            WHEN 'CRITICAL' THEN 1
            WHEN 'HIGH' THEN 2
            ELSE 3
        END,

        order_value DESC,

        delay_minutes DESC

    LIMIT 30;
    """
}


# ============================================================
# MAIN
# ============================================================

def main():

    print("=" * 70)
    print("PHASE 8.3 - SQL VIEWS & BUSINESS QUERIES")
    print("=" * 70)

    password = input(
        "\nEnter MySQL root password: "
    )

    print("\nConnecting to MySQL...")

    connection = mysql.connector.connect(
        host=MYSQL_HOST,
        port=MYSQL_PORT,
        user=MYSQL_USER,
        password=password,
        database=DATABASE
    )

    cursor = connection.cursor()

    print(
        "MySQL connection successful."
    )

    print("\nCreating business intelligence views...")
    print("-" * 70)

    created_views = []

    for view_name, sql in VIEWS.items():

        cursor.execute(sql)

        created_views.append(
            view_name
        )

        print(
            f"[OK] {view_name}"
        )

    connection.commit()

    # --------------------------------------------------------
    # VERIFY VIEWS
    # --------------------------------------------------------

    print("\nVERIFYING VIEWS")
    print("-" * 70)

    cursor.execute(
        """
        SELECT
            TABLE_NAME
        FROM information_schema.VIEWS
        WHERE TABLE_SCHEMA = %s
        ORDER BY TABLE_NAME
        """,
        (DATABASE,)
    )

    database_views = [
        row[0]
        for row in cursor.fetchall()
    ]

    all_views_present = all(
        view in database_views
        for view in created_views
    )

    for view in created_views:

        if view in database_views:

            print(
                f"[PASS] {view}"
            )

        else:

            print(
                f"[FAIL] {view}"
            )

    # --------------------------------------------------------
    # EXECUTIVE KPI TEST
    # --------------------------------------------------------

    print("\nEXECUTIVE KPI TEST")
    print("-" * 70)

    cursor.execute(
        """
        SELECT *
        FROM vw_executive_kpis
        """
    )

    kpi = cursor.fetchone()

    kpi_columns = [
        column[0]
        for column in cursor.description
    ]

    kpi_data = dict(
        zip(
            kpi_columns,
            kpi
        )
    )

    print(
        f"Total Orders           : "
        f"{kpi_data['total_orders']:,}"
    )

    print(
        f"Total Order Value      : "
        f"₹{float(kpi_data['total_order_value']):,.2f}"
    )

    print(
        f"Average Delay          : "
        f"{float(kpi_data['average_delay_minutes']):.2f} min"
    )

    print(
        f"On-Time Rate           : "
        f"{float(kpi_data['on_time_rate_pct']):.2f}%"
    )

    print(
        f"Orders at Risk         : "
        f"{kpi_data['orders_at_risk']:,}"
    )

    print(
        f"Order Value at Risk    : "
        f"₹{float(kpi_data['order_value_at_risk']):,.2f}"
    )

    print(
        f"Critical Orders        : "
        f"{kpi_data['critical_orders']:,}"
    )

    # --------------------------------------------------------
    # ZONE TEST
    # --------------------------------------------------------

    cursor.execute(
        """
        SELECT COUNT(*)
        FROM vw_zone_performance
        """
    )

    zone_count = cursor.fetchone()[0]

    print("\nZONE VIEW")
    print("-" * 70)

    print(
        f"Zones available        : "
        f"{zone_count}"
    )

    # --------------------------------------------------------
    # RISK TEST
    # --------------------------------------------------------

    cursor.execute(
        """
        SELECT
            risk_level,
            orders
        FROM vw_risk_distribution
        ORDER BY
            CASE risk_level
                WHEN 'LOW' THEN 1
                WHEN 'MEDIUM' THEN 2
                WHEN 'HIGH' THEN 3
                WHEN 'CRITICAL' THEN 4
                ELSE 5
            END
        """
    )

    risk_rows = cursor.fetchall()

    print("\nRISK VIEW")
    print("-" * 70)

    risk_total = 0

    for risk, orders in risk_rows:

        print(
            f"{risk:<15}: {orders:,}"
        )

        risk_total += orders

    # --------------------------------------------------------
    # INTERVENTION TEST
    # --------------------------------------------------------

    cursor.execute(
        """
        SELECT COUNT(*)
        FROM vw_intervention_candidates
        """
    )

    intervention_count = cursor.fetchone()[0]

    print("\nINTERVENTION VIEW")
    print("-" * 70)

    print(
        f"Top intervention candidates : "
        f"{intervention_count}"
    )

    # --------------------------------------------------------
    # VALIDATION
    # --------------------------------------------------------

    validation_passed = (

        len(created_views) == 6

        and all_views_present

        and kpi_data["total_orders"] == 1000

        and abs(
            float(
                kpi_data["total_order_value"]
            )
            - 37735702.89
        ) < 0.01

        and kpi_data["orders_at_risk"] == 344

        and abs(
            float(
                kpi_data["order_value_at_risk"]
            )
            - 12776135.22
        ) < 0.01

        and kpi_data["critical_orders"] == 225

        and risk_total == 1000

        and zone_count == 8

        and intervention_count == 30
    )

    # --------------------------------------------------------
    # CLOSE
    # --------------------------------------------------------

    cursor.close()
    connection.close()

    # --------------------------------------------------------
    # FINAL RESULT
    # --------------------------------------------------------

    print("\n" + "=" * 70)

    if validation_passed:

        print(
            "RESULT: PHASE 8.3 VALIDATION PASSED"
        )

        print(
            "SQL BUSINESS INTELLIGENCE LAYER READY"
        )

    else:

        print(
            "RESULT: VALIDATION ISSUES DETECTED"
        )

    print("=" * 70)


if __name__ == "__main__":
    main()