import csv
import json
import time
from pathlib import Path

from kafka import KafkaProducer
from kafka.errors import KafkaError


# ============================================================
# REAL-TIME LOGISTICS CONTROL TOWER
# PHASE 5.6 — ORDER PRODUCER
# ============================================================

BASE_DIR = Path(__file__).resolve().parent.parent

DATA_FILE = (
    BASE_DIR
    / "data"
    / "order_events.csv"
)

KAFKA_SERVER = "localhost:9092"

TOPIC = "order_events"

STREAM_DELAY_SECONDS = 0.05


# ============================================================
# KAFKA PRODUCER
# ============================================================

producer = KafkaProducer(

    bootstrap_servers=KAFKA_SERVER,

    key_serializer=lambda key:
        key.encode("utf-8"),

    value_serializer=lambda value:
        json.dumps(value).encode("utf-8"),

    acks="all"
)


# ============================================================
# LOAD ORDER DATA
# ============================================================

if not DATA_FILE.exists():

    print(
        f"ERROR: Data file not found:"
        f"\n{DATA_FILE}"
    )

    producer.close()

    raise SystemExit(1)


with open(
    DATA_FILE,
    "r",
    encoding="utf-8"
) as file:

    reader = csv.DictReader(file)

    rows = list(reader)


print("=" * 65)
print("REAL-TIME LOGISTICS CONTROL TOWER")
print("ORDER EVENT PRODUCER")
print("=" * 65)

print(
    f"Source file : {DATA_FILE}"
)

print(
    f"Kafka server: {KAFKA_SERVER}"
)

print(
    f"Kafka topic : {TOPIC}"
)

print(
    f"Records     : {len(rows):,}"
)

print("=" * 65)


# ============================================================
# STREAM EVENTS
# ============================================================

successful = 0
failed = 0


for row_number, row in enumerate(
    rows,
    start=1
):

    try:

        # ----------------------------------------------------
        # VALIDATE REQUIRED FIELDS
        # ----------------------------------------------------

        required_fields = [
            "order_id",
            "customer_id",
            "order_timestamp",
            "origin_zone",
            "destination_zone",
            "warehouse_id",
            "order_value",
            "priority"
        ]


        missing_fields = [

            field
            for field in required_fields

            if (
                field not in row
                or row[field] is None
                or str(row[field]).strip() == ""
            )
        ]


        if missing_fields:

            print(
                f"[SKIPPED] Row {row_number}: "
                f"Missing fields "
                f"{missing_fields}"
            )

            failed += 1

            continue


        # ----------------------------------------------------
        # CREATE STREAMING EVENT
        # ----------------------------------------------------

        event = {

            "event_id":
                f"ORD-EVT-{row_number:06d}",

            "event_timestamp":
                row["order_timestamp"],

            "event_type":
                "ORDER_CREATED",

            "order_id":
                row["order_id"],

            "customer_id":
                row["customer_id"],

            "origin_zone":
                row["origin_zone"],

            "destination_zone":
                row["destination_zone"],

            "warehouse_id":
                row["warehouse_id"],

            "order_value":
                float(row["order_value"]),

            "priority":
                row["priority"]
        }


        # ----------------------------------------------------
        # SEND TO KAFKA
        # ----------------------------------------------------

        future = producer.send(

            TOPIC,

            key=row["order_id"],

            value=event
        )


        # Wait for broker acknowledgement

        metadata = future.get(
            timeout=10
        )


        successful += 1


        # ----------------------------------------------------
        # DISPLAY PROGRESS
        # ----------------------------------------------------

        if (
            successful <= 10
            or successful % 100 == 0
        ):

            print(
                f"[SENT] "
                f"Order={row['order_id']} | "
                f"Partition={metadata.partition} | "
                f"Offset={metadata.offset}"
            )


        # ----------------------------------------------------
        # CONTROL STREAMING SPEED
        # ----------------------------------------------------

        time.sleep(
            STREAM_DELAY_SECONDS
        )


    except KafkaError as error:

        failed += 1

        print(
            f"[KAFKA ERROR] "
            f"Row {row_number}: {error}"
        )


    except Exception as error:

        failed += 1

        print(
            f"[ERROR] "
            f"Row {row_number}: {error}"
        )


# ============================================================
# FLUSH AND CLOSE
# ============================================================

producer.flush()

producer.close()


# ============================================================
# FINAL SUMMARY
# ============================================================

print("\n" + "=" * 65)
print("ORDER STREAMING COMPLETE")
print("=" * 65)

print(
    f"Successful events : {successful:,}"
)

print(
    f"Failed events     : {failed:,}"
)

print(
    f"Total processed   : "
    f"{successful + failed:,}"
)

print(
    f"Kafka topic       : {TOPIC}"
)

print("=" * 65)