# Kafka Configuration

KAFKA_BOOTSTRAP_SERVERS = ["localhost:9092"]

KAFKA_GROUP_ID = "logistics_control_tower_processor"

KAFKA_TOPICS = [
    "order_events",
    "shipment_events",
    "vehicle_events",
    "delivery_events"
]