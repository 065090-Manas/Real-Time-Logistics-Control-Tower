import csv
import os
from datetime import datetime


# ============================================================
# PROJECT PATHS
# ============================================================

BASE_DIR = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)

DATA_DIR = os.path.join(
    BASE_DIR,
    "data"
)

ANALYTICS_DIR = os.path.join(
    BASE_DIR,
    "analytics"
)

OUTPUT_FILE = os.path.join(
    ANALYTICS_DIR,
    "logistics_analytical_dataset.csv"
)

VALIDATION_FILE = os.path.join(
    ANALYTICS_DIR,
    "ANALYTICAL_DATASET_VALIDATION.txt"
)


# ============================================================
# INPUT FILES
# ============================================================

ORDER_FILE = os.path.join(
    DATA_DIR,
    "order_events.csv"
)

SHIPMENT_FILE = os.path.join(
    DATA_DIR,
    "shipment_events.csv"
)

VEHICLE_FILE = os.path.join(
    DATA_DIR,
    "vehicle_events.csv"
)

DELIVERY_FILE = os.path.join(
    DATA_DIR,
    "delivery_events.csv"
)


# ============================================================
# TIMESTAMP PARSER
# ============================================================

def parse_timestamp(value):

    if value is None:
        raise ValueError(
            "Timestamp is None"
        )

    value = str(value).strip()

    if not value:
        raise ValueError(
            "Timestamp is empty"
        )

    value = value.replace(
        "Z",
        ""
    )

    if "+" in value:
        value = value.split("+")[0]

    formats = [
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d %H:%M",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%dT%H:%M"
    ]

    for fmt in formats:

        try:

            return datetime.strptime(
                value,
                fmt
            )

        except ValueError:
            continue

    raise ValueError(
        f"Unable to parse timestamp: {value}"
    )


# ============================================================
# CSV READER
# ============================================================

def read_csv_file(filepath):

    with open(
        filepath,
        "r",
        encoding="utf-8-sig",
        newline=""
    ) as file:

        return list(
            csv.DictReader(file)
        )


# ============================================================
# RISK ENGINE
# ============================================================

def calculate_risk_level(
    delay_minutes,
    vehicle_status,
    priority,
    delivery_status
):

    delay_minutes = float(
        delay_minutes or 0
    )

    vehicle_status = str(
        vehicle_status or "MOVING"
    ).upper()

    priority = str(
        priority or "STANDARD"
    ).upper()

    delivery_status = str(
        delivery_status or "DELIVERED"
    ).upper()

    # --------------------------------------------------------
    # FAILED DELIVERY
    # --------------------------------------------------------

    if delivery_status == "FAILED":

        return "CRITICAL"

    # --------------------------------------------------------
    # BASE RISK FROM DELAY
    # --------------------------------------------------------

    if delay_minutes > 60:

        risk_score = 4

    elif delay_minutes > 30:

        risk_score = 3

    elif delay_minutes > 15:

        risk_score = 2

    else:

        risk_score = 1

    # --------------------------------------------------------
    # VEHICLE CONDITION
    # --------------------------------------------------------

    if vehicle_status in [
        "STOPPED",
        "DELAYED"
    ]:

        risk_score += 1

    # --------------------------------------------------------
    # PRIORITY
    # --------------------------------------------------------

    if priority == "HIGH":

        risk_score += 1

    elif (
        priority == "EXPRESS"
        and delay_minutes > 0
    ):

        risk_score += 1

    # --------------------------------------------------------
    # CAP SCORE
    # --------------------------------------------------------

    risk_score = min(
        risk_score,
        4
    )

    # --------------------------------------------------------
    # FINAL LEVEL
    # --------------------------------------------------------

    if risk_score >= 4:

        return "CRITICAL"

    elif risk_score == 3:

        return "HIGH"

    elif risk_score == 2:

        return "MEDIUM"

    else:

        return "LOW"


# ============================================================
# RISK SCORE
# ============================================================

def get_risk_score(risk_level):

    scores = {
        "LOW": 1,
        "MEDIUM": 2,
        "HIGH": 3,
        "CRITICAL": 4
    }

    return scores.get(
        risk_level,
        0
    )


# ============================================================
# MAIN ANALYTICAL DATASET PREPARATION
# ============================================================

def prepare_analytical_dataset():

    print("=" * 70)
    print("PHASE 7.1 - ANALYTICAL DATASET PREPARATION")
    print("=" * 70)

    # --------------------------------------------------------
    # CREATE ANALYTICS DIRECTORY
    # --------------------------------------------------------

    os.makedirs(
        ANALYTICS_DIR,
        exist_ok=True
    )

    # --------------------------------------------------------
    # LOAD DATA
    # --------------------------------------------------------

    print("\nLoading Phase 3 baseline datasets...")

    orders = read_csv_file(
        ORDER_FILE
    )

    shipment_events = read_csv_file(
        SHIPMENT_FILE
    )

    vehicle_events = read_csv_file(
        VEHICLE_FILE
    )

    deliveries = read_csv_file(
        DELIVERY_FILE
    )

    print(
        f"Orders loaded            : {len(orders):,}"
    )

    print(
        f"Shipment events loaded   : "
        f"{len(shipment_events):,}"
    )

    print(
        f"Vehicle events loaded    : "
        f"{len(vehicle_events):,}"
    )

    print(
        f"Delivery events loaded   : "
        f"{len(deliveries):,}"
    )

    # ========================================================
    # BUILD ORDER STATE
    # ========================================================

    order_state = {}

    for order in orders:

        order_id = order.get(
            "order_id"
        )

        if order_id:

            order_state[
                order_id
            ] = order

    # ========================================================
    # BUILD LATEST SHIPMENT STATE
    #
    # A shipment can have multiple events.
    # The latest event becomes the current shipment state.
    # ========================================================

    shipment_state = {}

    for shipment in shipment_events:

        shipment_id = shipment.get(
            "shipment_id"
        )

        if shipment_id:

            shipment_state[
                shipment_id
            ] = shipment

    # ========================================================
    # BUILD LATEST VEHICLE STATE
    #
    # A vehicle can generate many operational events.
    # The latest event becomes the current vehicle state.
    # ========================================================

    vehicle_state = {}

    for vehicle in vehicle_events:

        vehicle_id = vehicle.get(
            "vehicle_id"
        )

        if vehicle_id:

            vehicle_state[
                vehicle_id
            ] = vehicle

    # ========================================================
    # BUILD DELIVERY STATE
    #
    # One delivery record per shipment.
    # ========================================================

    delivery_state = {}

    for delivery in deliveries:

        shipment_id = delivery.get(
            "shipment_id"
        )

        if shipment_id:

            delivery_state[
                shipment_id
            ] = delivery

    # ========================================================
    # PREPARE ANALYTICAL RECORDS
    # ========================================================

    analytical_records = []

    missing_orders = 0

    missing_shipments = 0

    missing_vehicles = 0

    invalid_durations = 0

    # ========================================================
    # JOIN DELIVERY → SHIPMENT → ORDER → VEHICLE
    # ========================================================

    for shipment_id, delivery in delivery_state.items():

        # ----------------------------------------------------
        # SHIPMENT
        # ----------------------------------------------------

        shipment = shipment_state.get(
            shipment_id
        )

        if not shipment:

            missing_shipments += 1

            continue

        # ----------------------------------------------------
        # ORDER
        # ----------------------------------------------------

        order_id = shipment.get(
            "order_id"
        )

        if not order_id:

            order_id = delivery.get(
                "order_id"
            )

        order = order_state.get(
            order_id
        )

        if not order:

            missing_orders += 1

            continue

        # ----------------------------------------------------
        # VEHICLE
        # ----------------------------------------------------

        vehicle_id = shipment.get(
            "vehicle_id"
        )

        vehicle = vehicle_state.get(
            vehicle_id
        )

        if not vehicle:

            missing_vehicles += 1

        # ----------------------------------------------------
        # TIMESTAMPS
        #
        # IMPORTANT:
        # Kafka order events use event_timestamp.
        # ----------------------------------------------------

        order_timestamp = order.get("order_timestamp") or order.get("event_timestamp")
        

        actual_delivery_timestamp = (
            delivery.get(
                "actual_delivery_timestamp"
            )
        )

        if not actual_delivery_timestamp:

            actual_delivery_timestamp = (
                delivery.get(
                    "event_timestamp"
                )
            )

        delivery_time_minutes = 0

        duration_valid = True

        try:

            order_time = parse_timestamp(
                order_timestamp
            )

            delivery_time = parse_timestamp(
                actual_delivery_timestamp
            )

            delivery_time_minutes = (
                delivery_time - order_time
            ).total_seconds() / 60

            if delivery_time_minutes < 0:

                delivery_time_minutes = 0

                duration_valid = False

                invalid_durations += 1

        except Exception:

            duration_valid = False

            invalid_durations += 1

        # ----------------------------------------------------
        # DELIVERY ATTRIBUTES
        # ----------------------------------------------------

        delay_minutes = float(
            delivery.get(
                "delay_minutes",
                0
            )
            or 0
        )

        delivery_status = delivery.get(
            "delivery_status",
            "UNKNOWN"
        )

        # ----------------------------------------------------
        # VEHICLE ATTRIBUTES
        # ----------------------------------------------------

        if vehicle:

            vehicle_status = vehicle.get(
                "vehicle_status",
                "UNKNOWN"
            )

            speed_kmh = float(
                vehicle.get(
                    "speed_kmh",
                    0
                )
                or 0
            )

            current_zone = vehicle.get(
                "zone",
                ""
            )

        else:

            vehicle_status = "UNKNOWN"

            speed_kmh = 0

            current_zone = ""

        # ----------------------------------------------------
        # ORDER ATTRIBUTES
        # ----------------------------------------------------

        priority = order.get(
            "priority",
            "Standard"
        )

        order_value = float(
            order.get(
                "order_value",
                0
            )
            or 0
        )

        origin_zone = order.get(
            "origin_zone",
            ""
        )

        destination_zone = order.get(
            "destination_zone",
            delivery.get(
                "destination_zone",
                ""
            )
        )

        # ----------------------------------------------------
        # RISK
        # ----------------------------------------------------

        risk_level = calculate_risk_level(

            delay_minutes,

            vehicle_status,

            priority,

            delivery_status
        )

        risk_score = get_risk_score(
            risk_level
        )

        # ----------------------------------------------------
        # BUSINESS IMPACT
        # ----------------------------------------------------

        is_at_risk = (
            risk_level
            in [
                "HIGH",
                "CRITICAL"
            ]
        )

        is_critical = (
            risk_level
            == "CRITICAL"
        )

        # ----------------------------------------------------
        # ANALYTICAL RECORD
        # ----------------------------------------------------

        record = {

            "shipment_id":
                shipment_id,

            "order_id":
                order_id,

            "vehicle_id":
                vehicle_id or "",

            "warehouse_id":
                shipment.get(
                    "warehouse_id",
                    order.get(
                        "warehouse_id",
                        ""
                    )
                ),

            "origin_zone":
                origin_zone,

            "destination_zone":
                destination_zone,

            "current_vehicle_zone":
                current_zone,

            "priority":
                priority,

            "order_value":
                round(
                    order_value,
                    2
                ),

            "delivery_status":
                delivery_status,

            "delay_minutes":
                round(
                    delay_minutes,
                    2
                ),

            "delivery_time_minutes":
                round(
                    delivery_time_minutes,
                    2
                ),

            "vehicle_status":
                vehicle_status,

            "speed_kmh":
                round(
                    speed_kmh,
                    2
                ),

            "risk_level":
                risk_level,

            "risk_score":
                risk_score,

            "is_at_risk":
                "YES"
                if is_at_risk
                else "NO",

            "is_critical":
                "YES"
                if is_critical
                else "NO",

            "order_timestamp":
                order_timestamp,

            "expected_delivery_timestamp":
                delivery.get(
                    "expected_delivery_timestamp",
                    ""
                ),

            "actual_delivery_timestamp":
                actual_delivery_timestamp,

            "duration_valid":
                "YES"
                if duration_valid
                else "NO"
        }

        analytical_records.append(
            record
        )

    # ========================================================
    # WRITE ANALYTICAL CSV
    # ========================================================

    fieldnames = [

        "shipment_id",

        "order_id",

        "vehicle_id",

        "warehouse_id",

        "origin_zone",

        "destination_zone",

        "current_vehicle_zone",

        "priority",

        "order_value",

        "delivery_status",

        "delay_minutes",

        "delivery_time_minutes",

        "vehicle_status",

        "speed_kmh",

        "risk_level",

        "risk_score",

        "is_at_risk",

        "is_critical",

        "order_timestamp",

        "expected_delivery_timestamp",

        "actual_delivery_timestamp",

        "duration_valid"
    ]

    with open(
        OUTPUT_FILE,
        "w",
        encoding="utf-8",
        newline=""
    ) as file:

        writer = csv.DictWriter(
            file,
            fieldnames=fieldnames
        )

        writer.writeheader()

        writer.writerows(
            analytical_records
        )

    # ========================================================
    # VALIDATION
    # ========================================================

    total_records = len(
        analytical_records
    )

    risk_counts = {
        "LOW": 0,
        "MEDIUM": 0,
        "HIGH": 0,
        "CRITICAL": 0
    }

    at_risk_count = 0

    critical_count = 0

    order_value_at_risk = 0

    critical_order_value = 0

    for record in analytical_records:

        risk_level = record[
            "risk_level"
        ]

        if risk_level in risk_counts:

            risk_counts[
                risk_level
            ] += 1

        if record[
            "is_at_risk"
        ] == "YES":

            at_risk_count += 1

            order_value_at_risk += float(
                record[
                    "order_value"
                ]
            )

        if record[
            "is_critical"
        ] == "YES":

            critical_count += 1

            critical_order_value += float(
                record[
                    "order_value"
                ]
            )

    valid_duration_count = sum(
        1
        for record in analytical_records
        if record[
            "duration_valid"
        ] == "YES"
    )

    # ========================================================
    # WRITE VALIDATION REPORT
    # ========================================================

    validation_lines = [

        "REAL-TIME LOGISTICS CONTROL TOWER",

        "PHASE 7.1 ANALYTICAL DATASET VALIDATION",

        "",

        "STATUS: COMPLETE",

        "",

        "SOURCE DATA",

        f"Orders: {len(orders):,}",

        f"Shipment events: {len(shipment_events):,}",

        f"Vehicle events: {len(vehicle_events):,}",

        f"Delivery events: {len(deliveries):,}",

        "",

        "ANALYTICAL DATASET",

        f"Analytical records: {total_records:,}",

        f"Expected analytical records: {len(delivery_state):,}",

        "",

        "DATA QUALITY",

        f"Missing orders: {missing_orders:,}",

        f"Missing shipments: {missing_shipments:,}",

        f"Missing vehicles: {missing_vehicles:,}",

        f"Valid delivery durations: {valid_duration_count:,}",

        f"Invalid delivery durations: {invalid_durations:,}",

        "",

        "RISK DISTRIBUTION",

        f"LOW: {risk_counts['LOW']:,}",

        f"MEDIUM: {risk_counts['MEDIUM']:,}",

        f"HIGH: {risk_counts['HIGH']:,}",

        f"CRITICAL: {risk_counts['CRITICAL']:,}",

        "",

        "BUSINESS IMPACT",

        f"Orders at Risk: {at_risk_count:,}",

        f"Order Value at Risk: ₹{order_value_at_risk:,.2f}",

        f"Critical Orders: {critical_count:,}",

        f"Critical Order Value: ₹{critical_order_value:,.2f}",

        "",

        "OUTPUT FILE",

        OUTPUT_FILE,

        "",

        "PHASE 7.1 STATUS: FROZEN"
    ]

    with open(
        VALIDATION_FILE,
        "w",
        encoding="utf-8"
    ) as file:

        file.write(
            "\n".join(
                validation_lines
            )
        )

    # ========================================================
    # CONSOLE OUTPUT
    # ========================================================

    print("\n" + "=" * 70)

    print(
        "PHASE 7.1 VALIDATION"
    )

    print("=" * 70)

    print(
        f"Analytical records      : "
        f"{total_records:,}"
    )

    print(
        f"Expected records       : "
        f"{len(delivery_state):,}"
    )

    print(
        f"Missing orders          : "
        f"{missing_orders:,}"
    )

    print(
        f"Missing shipments       : "
        f"{missing_shipments:,}"
    )

    print(
        f"Missing vehicles        : "
        f"{missing_vehicles:,}"
    )

    print(
        f"Valid durations         : "
        f"{valid_duration_count:,}"
    )

    print(
        f"Invalid durations       : "
        f"{invalid_durations:,}"
    )

    print("\nRISK DISTRIBUTION")

    print("-" * 70)

    print(
        f"LOW                     : "
        f"{risk_counts['LOW']:,}"
    )

    print(
        f"MEDIUM                  : "
        f"{risk_counts['MEDIUM']:,}"
    )

    print(
        f"HIGH                    : "
        f"{risk_counts['HIGH']:,}"
    )

    print(
        f"CRITICAL                : "
        f"{risk_counts['CRITICAL']:,}"
    )

    print("\nBUSINESS IMPACT")

    print("-" * 70)

    print(
        f"Orders at Risk          : "
        f"{at_risk_count:,}"
    )

    print(
        f"Order Value at Risk     : "
        f"₹{order_value_at_risk:,.2f}"
    )

    print(
        f"Critical Orders         : "
        f"{critical_count:,}"
    )

    print(
        f"Critical Order Value    : "
        f"₹{critical_order_value:,.2f}"
    )

    print("\nOUTPUT")

    print("-" * 70)

    print(
        f"Analytical Dataset      : "
        f"{OUTPUT_FILE}"
    )

    print(
        f"Validation Report       : "
        f"{VALIDATION_FILE}"
    )

    # ========================================================
    # FINAL STATUS
    # ========================================================

    if (
        total_records == len(delivery_state)
        and missing_orders == 0
        and missing_shipments == 0
        and invalid_durations == 0
        and (
            sum(
                risk_counts.values()
            )
            == total_records
        )
    ):

        print("\n" + "=" * 70)

        print(
            "RESULT: PHASE 7.1 VALIDATION PASSED"
        )

        print("=" * 70)

    else:

        print("\n" + "=" * 70)

        print(
            "RESULT: VALIDATION ISSUES DETECTED"
        )

        print("=" * 70)


# ============================================================
# PROGRAM ENTRY POINT
# ============================================================

if __name__ == "__main__":

    prepare_analytical_dataset()