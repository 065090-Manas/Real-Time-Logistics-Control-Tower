import csv
import os
from collections import defaultdict


BASE_DIR = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)

ANALYTICS_DIR = os.path.join(BASE_DIR, "analytics")

INPUT_FILE = os.path.join(
    ANALYTICS_DIR,
    "logistics_analytical_dataset.csv"
)

OUTPUT_FILE = os.path.join(
    ANALYTICS_DIR,
    "zone_performance.csv"
)

VALIDATION_FILE = os.path.join(
    ANALYTICS_DIR,
    "ZONE_PERFORMANCE_VALIDATION.txt"
)


def read_csv_file(filepath):
    with open(
        filepath,
        "r",
        encoding="utf-8-sig",
        newline=""
    ) as file:
        return list(csv.DictReader(file))


def calculate_zone_performance(records):

    zones = defaultdict(
        lambda: {
            "orders": 0,
            "order_value": 0.0,
            "delay_total": 0.0,
            "on_time": 0,
            "delayed": 0,
            "at_risk": 0,
            "critical": 0,
            "failed": 0,
            "delivery_time_total": 0.0
        }
    )

    for record in records:

        zone = (
            record.get("destination_zone")
            or "UNKNOWN"
        ).strip()

        order_value = float(
            record.get("order_value", 0) or 0
        )

        delay = float(
            record.get("delay_minutes", 0) or 0
        )

        delivery_time = float(
            record.get("delivery_time_minutes", 0) or 0
        )

        risk_level = (
            record.get("risk_level")
            or "UNKNOWN"
        ).upper()

        delivery_status = (
            record.get("delivery_status")
            or "UNKNOWN"
        ).upper()

        zones[zone]["orders"] += 1

        zones[zone]["order_value"] += order_value

        zones[zone]["delay_total"] += delay

        zones[zone]["delivery_time_total"] += delivery_time

        if delay <= 0:
            zones[zone]["on_time"] += 1
        else:
            zones[zone]["delayed"] += 1

        if risk_level in ["HIGH", "CRITICAL"]:
            zones[zone]["at_risk"] += 1

        if risk_level == "CRITICAL":
            zones[zone]["critical"] += 1

        if delivery_status == "FAILED":
            zones[zone]["failed"] += 1

    results = []

    for zone, data in zones.items():

        orders = data["orders"]

        avg_delay = (
            data["delay_total"] / orders
            if orders > 0
            else 0
        )

        avg_delivery_time = (
            data["delivery_time_total"] / orders
            if orders > 0
            else 0
        )

        on_time_rate = (
            data["on_time"] / orders * 100
            if orders > 0
            else 0
        )

        delayed_rate = (
            data["delayed"] / orders * 100
            if orders > 0
            else 0
        )

        risk_rate = (
            data["at_risk"] / orders * 100
            if orders > 0
            else 0
        )

        critical_rate = (
            data["critical"] / orders * 100
            if orders > 0
            else 0
        )

        result = {
            "destination_zone": zone,
            "orders": orders,
            "order_value": round(data["order_value"], 2),
            "average_delay_minutes": round(avg_delay, 2),
            "average_delivery_time_minutes": round(
                avg_delivery_time,
                2
            ),
            "on_time_deliveries": data["on_time"],
            "on_time_rate_pct": round(
                on_time_rate,
                2
            ),
            "delayed_deliveries": data["delayed"],
            "delayed_rate_pct": round(
                delayed_rate,
                2
            ),
            "at_risk_shipments": data["at_risk"],
            "risk_rate_pct": round(
                risk_rate,
                2
            ),
            "critical_shipments": data["critical"],
            "critical_rate_pct": round(
                critical_rate,
                2
            ),
            "failed_deliveries": data["failed"]
        }

        results.append(result)

    # Highest risk first
    results.sort(
        key=lambda x: (
            x["risk_rate_pct"],
            x["average_delay_minutes"],
            x["at_risk_shipments"]
        ),
        reverse=True
    )

    return results


def main():

    print("=" * 70)
    print("PHASE 7.2 - ZONE & REGIONAL PERFORMANCE ANALYSIS")
    print("=" * 70)

    print("\nLoading frozen Phase 7.1 analytical dataset...")

    records = read_csv_file(INPUT_FILE)

    print(
        f"Analytical records loaded : {len(records):,}"
    )

    if not records:
        print("\nERROR: Analytical dataset is empty.")
        return

    results = calculate_zone_performance(records)

    # ---------------------------------------------------------
    # WRITE ZONE PERFORMANCE DATASET
    # ---------------------------------------------------------

    fieldnames = [
        "destination_zone",
        "orders",
        "order_value",
        "average_delay_minutes",
        "average_delivery_time_minutes",
        "on_time_deliveries",
        "on_time_rate_pct",
        "delayed_deliveries",
        "delayed_rate_pct",
        "at_risk_shipments",
        "risk_rate_pct",
        "critical_shipments",
        "critical_rate_pct",
        "failed_deliveries"
    ]

    with open(
        OUTPUT_FILE,
        "w",
        encoding="utf-8",
        newline=""
    ) as file:

        writer = csv.DictWriter(
            file,
            fieldnames=fieldnames
        )

        writer.writeheader()
        writer.writerows(results)

    # ---------------------------------------------------------
    # VALIDATION
    # ---------------------------------------------------------

    total_zone_orders = sum(
        row["orders"]
        for row in results
    )

    total_zone_value = sum(
        row["order_value"]
        for row in results
    )

    total_at_risk = sum(
        row["at_risk_shipments"]
        for row in results
    )

    total_critical = sum(
        row["critical_shipments"]
        for row in results
    )

    total_failed = sum(
        row["failed_deliveries"]
        for row in results
    )

    zone_count = len(results)

    highest_risk_zone = max(
        results,
        key=lambda x: x["risk_rate_pct"]
    )

    highest_delay_zone = max(
        results,
        key=lambda x: x["average_delay_minutes"]
    )

    lowest_ontime_zone = min(
        results,
        key=lambda x: x["on_time_rate_pct"]
    )

    validation_lines = [
        "REAL-TIME LOGISTICS CONTROL TOWER",
        "PHASE 7.2 ZONE & REGIONAL PERFORMANCE VALIDATION",
        "",
        "STATUS: COMPLETE",
        "",
        "SOURCE DATA",
        f"Analytical records: {len(records):,}",
        "",
        "ZONE COVERAGE",
        f"Zones identified: {zone_count:,}",
        "",
        "AGGREGATION VALIDATION",
        f"Total zone orders: {total_zone_orders:,}",
        f"Source analytical records: {len(records):,}",
        f"Total zone order value: ₹{total_zone_value:,.2f}",
        "",
        "RISK VALIDATION",
        f"At-risk shipments: {total_at_risk:,}",
        f"Critical shipments: {total_critical:,}",
        f"Failed deliveries: {total_failed:,}",
        "",
        "TOP PERFORMANCE EXCEPTIONS",
        f"Highest risk zone: {highest_risk_zone['destination_zone']}",
        f"Highest risk rate: {highest_risk_zone['risk_rate_pct']:.2f}%",
        f"Highest delay zone: {highest_delay_zone['destination_zone']}",
        f"Highest average delay: {highest_delay_zone['average_delay_minutes']:.2f} minutes",
        f"Lowest on-time zone: {lowest_ontime_zone['destination_zone']}",
        f"Lowest on-time rate: {lowest_ontime_zone['on_time_rate_pct']:.2f}%",
        "",
        "OUTPUT FILE",
        OUTPUT_FILE,
        "",
        "PHASE 7.2 STATUS: FROZEN"
    ]

    with open(
        VALIDATION_FILE,
        "w",
        encoding="utf-8"
    ) as file:

        file.write(
            "\n".join(validation_lines)
        )

    # ---------------------------------------------------------
    # DISPLAY RESULTS
    # ---------------------------------------------------------

    print("\n" + "=" * 70)
    print("ZONE PERFORMANCE SUMMARY")
    print("=" * 70)

    print(
        f"{'ZONE':<15}"
        f"{'ORDERS':>10}"
        f"{'AVG DELAY':>14}"
        f"{'ON-TIME %':>12}"
        f"{'AT RISK':>10}"
        f"{'CRITICAL':>10}"
    )

    print("-" * 70)

    for row in results:

        print(
            f"{row['destination_zone']:<15}"
            f"{row['orders']:>10,}"
            f"{row['average_delay_minutes']:>14.2f}"
            f"{row['on_time_rate_pct']:>12.2f}"
            f"{row['at_risk_shipments']:>10,}"
            f"{row['critical_shipments']:>10,}"
        )

    print("\n" + "=" * 70)
    print("PHASE 7.2 VALIDATION")
    print("=" * 70)

    print(
        f"Zones identified        : {zone_count:,}"
    )

    print(
        f"Zone orders             : {total_zone_orders:,}"
    )

    print(
        f"Source records          : {len(records):,}"
    )

    print(
        f"Zone order value        : ₹{total_zone_value:,.2f}"
    )

    print(
        f"At-risk shipments       : {total_at_risk:,}"
    )

    print(
        f"Critical shipments      : {total_critical:,}"
    )

    print(
        f"Failed deliveries       : {total_failed:,}"
    )

    print("\nTOP EXCEPTIONS")
    print("-" * 70)

    print(
        f"Highest risk zone       : "
        f"{highest_risk_zone['destination_zone']} "
        f"({highest_risk_zone['risk_rate_pct']:.2f}%)"
    )

    print(
        f"Highest delay zone      : "
        f"{highest_delay_zone['destination_zone']} "
        f"({highest_delay_zone['average_delay_minutes']:.2f} min)"
    )

    print(
        f"Lowest on-time zone     : "
        f"{lowest_ontime_zone['destination_zone']} "
        f"({lowest_ontime_zone['on_time_rate_pct']:.2f}%)"
    )

    print("\nOUTPUT")
    print("-" * 70)

    print(
        f"Zone Dataset            : {OUTPUT_FILE}"
    )

    print(
        f"Validation Report       : {VALIDATION_FILE}"
    )

    # ---------------------------------------------------------
    # FINAL VALIDATION
    # ---------------------------------------------------------

    if (
        total_zone_orders == len(records)
        and zone_count > 0
        and total_at_risk == sum(
            1
            for record in records
            if record.get("is_at_risk") == "YES"
        )
        and total_critical == sum(
            1
            for record in records
            if record.get("is_critical") == "YES"
        )
    ):

        print("\n" + "=" * 70)
        print("RESULT: PHASE 7.2 VALIDATION PASSED")
        print("=" * 70)

    else:

        print("\n" + "=" * 70)
        print("RESULT: VALIDATION ISSUES DETECTED")
        print("=" * 70)


if __name__ == "__main__":
    main()